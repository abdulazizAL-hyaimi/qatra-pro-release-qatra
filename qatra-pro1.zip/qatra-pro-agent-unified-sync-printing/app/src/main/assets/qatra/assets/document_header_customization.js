/* Qatra Pro document header designer for invoices and vouchers. */
(function(global){
'use strict';
let installed=false;
const $=selector=>document.querySelector(selector);
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const safeColor=value=>/^#[0-9a-f]{6}$/i.test(String(value||''))?String(value):'#0b6f91';
const prefixes={invoice:'invoice',receipt:'receipt'};
function ensureDefaults(save=false){
  if(!global.YWP?.state)return{};
  const settings=YWP.state.settings||(YWP.state.settings={});
  const genericMeta=[settings.projectAddress,settings.projectPhone1,settings.projectAccountNo].filter(Boolean).join(' | ');
  const defaults={invoiceHeaderTitle:settings.projectName||'اسم المشروع',invoiceHeaderSubtitle:settings.ownerName||'',invoiceHeaderMeta:genericMeta,invoiceHeaderLogoPosition:'right',invoiceHeaderLayout:'formal',invoiceHeaderAccentColor:'#0b6f91',receiptHeaderTitle:settings.projectName||'اسم المشروع',receiptHeaderSubtitle:settings.ownerName||'',receiptHeaderMeta:genericMeta,receiptHeaderLogoPosition:'right',receiptHeaderLayout:'formal',receiptHeaderAccentColor:'#0b6f91'};
  let changed=false;
  Object.keys(defaults).forEach(key=>{if(settings[key]===undefined||settings[key]===null){settings[key]=defaults[key];changed=true;}});
  if(changed&&save)YWP.save();
  return settings;
}
function field(label,id,value,type='text'){return `<div class="field"><label>${esc(label)}</label><input id="${id}" type="${type}" value="${esc(value)}" oninput="QatraDocumentHeaderDesigner.preview()" onchange="QatraDocumentHeaderDesigner.preview()"></div>`;}
function selectField(label,id,value,items){return `<div class="field"><label>${esc(label)}</label><select id="${id}" onchange="QatraDocumentHeaderDesigner.preview()">${items.map(item=>`<option value="${esc(item[0])}" ${item[0]===value?'selected':''}>${esc(item[1])}</option>`).join('')}</select></div>`;}
function id(kind,suffix){return`${kind}DocHeader${suffix}`;}
function read(kind,settings=ensureDefaults()){
  const prefix=prefixes[kind];
  const value=(suffix,fallback)=>document.getElementById(id(kind,suffix))?.value??fallback;
  return {headerTitle:value('Title',settings[`${prefix}HeaderTitle`]||settings.projectName||''),headerSubtitle:value('Subtitle',settings[`${prefix}HeaderSubtitle`]||''),headerMeta:value('Meta',settings[`${prefix}HeaderMeta`]||''),headerLogoPosition:value('LogoPosition',settings[`${prefix}HeaderLogoPosition`]||'right'),headerLayout:value('Layout',settings[`${prefix}HeaderLayout`]||'formal'),headerAccentColor:safeColor(value('Accent',settings[`${prefix}HeaderAccentColor`]||'#0b6f91')),logo:settings.projectLogo||''};
}
function write(kind,data){
  const prefix=prefixes[kind],settings=YWP.state.settings;
  settings[`${prefix}HeaderTitle`]=data.headerTitle;settings[`${prefix}HeaderSubtitle`]=data.headerSubtitle;settings[`${prefix}HeaderMeta`]=data.headerMeta;settings[`${prefix}HeaderLogoPosition`]=data.headerLogoPosition;settings[`${prefix}HeaderLayout`]=data.headerLayout;settings[`${prefix}HeaderAccentColor`]=data.headerAccentColor;
}
function preview(){
  if(!global.QatraPrint?.headerHtml)return;
  ['invoice','receipt'].forEach(kind=>{const target=document.getElementById(`${kind}DocHeaderPreview`);if(target)target.innerHTML=QatraPrint.headerHtml(read(kind));});
}
function editor(kind,title,settings){
  const prefix=prefixes[kind];
  return `<section class="document-header-editor"><div class="document-header-editor-title"><div><small>ترويسة مستقلة</small><h3>${esc(title)}</h3></div><span>${kind==='invoice'?'▤':'▣'}</span></div><div class="form-row">${field('العنوان الرئيسي',id(kind,'Title'),settings[`${prefix}HeaderTitle`]||'')}${field('العنوان الفرعي',id(kind,'Subtitle'),settings[`${prefix}HeaderSubtitle`]||'')}${field('بيانات التواصل / العنوان',id(kind,'Meta'),settings[`${prefix}HeaderMeta`]||'')}${selectField('موضع شعار المشروع',id(kind,'LogoPosition'),settings[`${prefix}HeaderLogoPosition`]||'right',[['right','يمين'],['center','وسط'],['left','يسار'],['hidden','بدون شعار']])}${selectField('نمط الترويسة',id(kind,'Layout'),settings[`${prefix}HeaderLayout`]||'formal',[['formal','رسمي'],['compact','مضغوط'],['minimal','بسيط']])}${field('لون الترويسة',id(kind,'Accent'),safeColor(settings[`${prefix}HeaderAccentColor`]),'color')}</div><div class="document-header-preview"><small>معاينة الترويسة</small><div id="${kind}DocHeaderPreview"></div></div></section>`;
}
function inject(){
  const host=$('#settings');if(!host||!host.children.length||$('#documentHeaderDesignerCard'))return;
  const settings=ensureDefaults(true);
  host.insertAdjacentHTML('beforeend',`<div class="card document-header-designer-card" id="documentHeaderDesignerCard"><div class="document-header-designer-intro"><div><h2>مصمم ترويسة الفواتير والسندات</h2><p>تُستخدم ترويسة مستقلة للفواتير وأخرى للسندات. شعار المشروع يظهر داخل الترويسة فقط، بينما تبقى علامة QATRA PRO في تذييل الورقة.</p></div><span>▦</span></div><div class="document-header-editor-grid">${editor('invoice','الفواتير',settings)}${editor('receipt','سندات القبض والصرف',settings)}</div><div class="notice">يتم أخذ صورة الشعار من حقل «شعار المشروع» في الإعدادات العامة. تغيير موضع الشعار أو إخفاؤه لا يغير ملف الشعار نفسه.</div><div class="toolbar"><button class="green" onclick="QatraDocumentHeaderDesigner.save()">حفظ تصميم الترويسات</button><button class="light" onclick="QatraDocumentHeaderDesigner.restoreDefaults()">استعادة الافتراضي</button></div></div>`);
  preview();
}
function save(){if(!global.YWP?.state)return;write('invoice',read('invoice'));write('receipt',read('receipt'));YWP.save();preview();alert('تم حفظ ترويسة الفواتير وترويسة السندات. ستظهر التغييرات في الطباعة الحرارية وA5.');}
function restoreDefaults(){
  if(!global.YWP?.state)return;
  const settings=YWP.state.settings||{},meta=[settings.projectAddress,settings.projectPhone1,settings.projectAccountNo].filter(Boolean).join(' | ');
  Object.assign(settings,{invoiceHeaderTitle:settings.projectName||'اسم المشروع',invoiceHeaderSubtitle:settings.ownerName||'',invoiceHeaderMeta:meta,invoiceHeaderLogoPosition:'right',invoiceHeaderLayout:'formal',invoiceHeaderAccentColor:'#0b6f91',receiptHeaderTitle:settings.projectName||'اسم المشروع',receiptHeaderSubtitle:settings.ownerName||'',receiptHeaderMeta:meta,receiptHeaderLogoPosition:'right',receiptHeaderLayout:'formal',receiptHeaderAccentColor:'#0b6f91'});
  YWP.save();$('#documentHeaderDesignerCard')?.remove();inject();
}
function install(){
  if(!global.YWP||!global.App||!global.QatraPrint)return setTimeout(install,200);
  ensureDefaults(true);
  if(!installed){const observer=new MutationObserver(()=>setTimeout(inject,0));observer.observe(document.body,{childList:true,subtree:true});installed=true;}
  inject();
}
global.QatraDocumentHeaderDesigner={install,inject,preview,save,restoreDefaults,read};
install();global.addEventListener('load',()=>setTimeout(install,50));
})(window);
