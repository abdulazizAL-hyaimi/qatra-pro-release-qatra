/* Qatra Pro unified document renderer: A4, A5, 58 mm and 80 mm. */
(function(global){
'use strict';

const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const number=value=>{const parsed=Number(String(value??0).replace(/[,،\s]/g,''));return Number.isFinite(parsed)?parsed:0;};
const formatNumber=value=>number(value).toLocaleString('en-US');
const paperToken=value=>{const token=String(value||'A5').toUpperCase();return['A4','A5','58MM','80MM'].includes(token)?token:'A5';};
const money=(value,currency='ر.ي')=>`${formatNumber(value)} ${esc(currency||'ر.ي')}`;

function qrHtml(data,label){
  const text=String(data?.qrText||'').trim();
  if(!text)return'';
  try{return global.QatraQr?.html?.(text,label||'امسح للتحقق من الوثيقة')||'';}catch(_){return'';}
}

function brand(data){
  const logo=data.logo||'assets/qatra-pro-mark.svg';
  return `<header class="qp-brand"><img src="${esc(logo)}" alt="شعار المشروع"><div><h1>${esc(data.projectName||'قطرة برو')}</h1>${data.projectSubtitle?`<p>${esc(data.projectSubtitle)}</p>`:''}${data.projectMeta?`<small>${esc(data.projectMeta)}</small>`:''}</div></header>`;
}

function qatraFooter(data){
  return `<footer class="qp-system-footer"><span>${esc(data.footer||'هذه الوثيقة صادرة من المشروع.')}</span><span class="qp-system-mark"><img src="assets/qatra-pro-mark.svg" alt="QATRA PRO"><b>QATRA PRO</b><small>نظام إدارة خدمات المياه</small></span></footer>`;
}

function rows(items){
  return (items||[]).filter(item=>item&&item.value!==undefined&&item.value!==null&&String(item.value)!=='').map(item=>`<div class="qp-field ${item.wide?'wide':''}"><span>${esc(item.label)}</span><b class="${item.ltr?'ltr':''}">${esc(item.value)}</b></div>`).join('');
}

function receipt(data,thermal){
  const before=data.balanceBefore;
  const after=data.balanceAfter;
  const hasBefore=before!==undefined&&before!==null;
  const hasAfter=after!==undefined&&after!==null;
  const beforeText=data.balanceBeforeLabel||'الرصيد قبل السداد';
  const afterText=data.balanceAfterLabel||'الرصيد بعد السداد';
  const balanceCards=`${hasBefore?`<div><span>${esc(beforeText)}</span><b>${money(Math.abs(number(before)),data.currency)}${data.balanceBeforeSuffix?` ${esc(data.balanceBeforeSuffix)}`:''}</b></div>`:''}${hasAfter?`<div class="${number(after)>0?'due':number(after)<0?'credit':'zero'}"><span>${esc(afterText)}</span><b>${money(Math.abs(number(after)),data.currency)}${data.balanceAfterSuffix?` ${esc(data.balanceAfterSuffix)}`:''}</b></div>`:''}`;
  return `<article class="qp-document qp-receipt ${thermal?'qp-thermal':''}">${brand(data)}<div class="qp-title"><h2>${esc(data.title||'سند قبض')}</h2><span>${esc(data.number||'')}</span></div><section class="qp-grid">${rows([
    {label:'التاريخ',value:data.date,ltr:true},
    {label:'اسم المشترك',value:data.subscriberName,wide:true},
    {label:'رقم المشترك',value:data.subscriberCode,ltr:true},
    {label:'رقم العداد',value:data.meterNo,ltr:true},
    {label:'طريقة الدفع',value:data.method},
    {label:'اسم المحصل',value:data.collector}
  ])}</section><section class="qp-amount"><span>المبلغ المسدد</span><b>${money(data.amount,data.currency)}</b></section>${balanceCards?`<section class="qp-balance-grid">${balanceCards}</section>`:''}${data.note?`<div class="qp-note"><span>ملاحظات</span><b>${esc(data.note)}</b></div>`:''}${qrHtml(data,'امسح للتحقق من السند')}<div class="qp-cert">${esc(data.certification||'هذا السند صادر من المشروع.')}</div>${thermal?'':`<div class="qp-signatures"><span>توقيع المحصل: __________________</span><span>توقيع المستلم: __________________</span></div>`}${qatraFooter(data)}</article>`;
}

function invoice(data){
  return `<article class="qp-document qp-invoice">${brand(data)}<div class="qp-title"><h2>${esc(data.title||'فاتورة استهلاك مياه')}</h2><span>${esc(data.number||'')}</span></div><section class="qp-grid">${rows([
    {label:'التاريخ',value:data.date,ltr:true},
    {label:'الدورة',value:data.cycle,wide:true},
    {label:'اسم المشترك',value:data.subscriberName,wide:true},
    {label:'رقم المشترك',value:data.subscriberCode,ltr:true},
    {label:'رقم العداد',value:data.meterNo,ltr:true},
    {label:'العنوان',value:data.address,wide:true}
  ])}</section><section class="qp-section"><h3>تفاصيل القراءة</h3><div class="qp-metrics"><div><span>القراءة السابقة</span><b>${formatNumber(data.previousReading)}</b></div><div><span>القراءة الحالية</span><b>${formatNumber(data.currentReading)}</b></div><div><span>الاستهلاك</span><b>${formatNumber(data.consumption)} م³</b></div><div><span>سعر الوحدة</span><b>${money(data.tariff,data.currency)}</b></div></div></section><section class="qp-section"><h3>البيان المالي</h3><div class="qp-finance"><div><span>قيمة الاستهلاك</span><b>${money(data.consumptionAmount,data.currency)}</b></div><div><span>المتأخرات</span><b>${money(data.arrears,data.currency)}</b></div><div><span>الرصيد المقدم</span><b>${money(data.credit,data.currency)}</b></div><div class="total"><span>إجمالي الفاتورة</span><b>${money(data.total,data.currency)}</b></div><div><span>المسدد</span><b>${money(data.paid,data.currency)}</b></div><div class="remaining"><span>الرصيد المتبقي</span><b>${money(data.remaining,data.currency)}</b></div></div></section>${data.totalWords?`<div class="qp-words"><span>الإجمالي كتابة</span><b>${esc(data.totalWords)}</b></div>`:''}${qrHtml(data,'امسح للتحقق من الفاتورة')}<div class="qp-signatures"><span>المحاسب: __________________</span><span>المستلم: __________________</span></div>${qatraFooter(data)}</article>`;
}

function voucher(data){
  const incoming=String(data.direction||'IN').toUpperCase()==='IN';
  return `<article class="qp-document qp-voucher ${incoming?'incoming':'outgoing'}">${brand(data)}<div class="qp-title"><h2>${esc(data.title||(incoming?'سند قبض':'سند صرف'))}</h2><span>${esc(data.number||'')}</span></div><section class="qp-grid">${rows([
    {label:'التاريخ',value:data.date,ltr:true},
    {label:incoming?'استلمنا من':'صُرف إلى',value:data.party,wide:true},
    {label:'طريقة الدفع',value:data.method},
    {label:'المرجع',value:data.reference,ltr:true},
    {label:'البيان',value:data.description,wide:true}
  ])}</section><section class="qp-amount"><span>${incoming?'المبلغ المقبوض':'المبلغ المصروف'}</span><b>${money(data.amount,data.currency)}</b></section>${data.amountWords?`<div class="qp-words"><span>المبلغ كتابة</span><b>${esc(data.amountWords)}</b></div>`:''}${data.note?`<div class="qp-note"><span>ملاحظات</span><b>${esc(data.note)}</b></div>`:''}${qrHtml(data,'امسح للتحقق من السند')}<div class="qp-signatures"><span>${incoming?'المستلم':'المستفيد'}: __________________</span><span>أمين الصندوق: __________________</span><span>الاعتماد: __________________</span></div>${qatraFooter(data)}</article>`;
}

function report(data){
  const columns=Array.isArray(data.columns)?data.columns:[];
  const body=(data.rows||[]).map(row=>`<tr>${columns.map(col=>`<td>${esc(typeof col==='string'?row?.[col]:row?.[col.key])}</td>`).join('')}</tr>`).join('');
  return `<article class="qp-document qp-report">${brand(data)}<div class="qp-title"><h2>${esc(data.title||'تقرير')}</h2><span>${esc(data.period||data.date||'')}</span></div>${Array.isArray(data.summary)?`<div class="qp-summary">${data.summary.map(item=>`<div><span>${esc(item.label)}</span><b>${esc(item.value)}</b></div>`).join('')}</div>`:''}<table><thead><tr>${columns.map(col=>`<th>${esc(typeof col==='string'?col:col.label)}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table><div class="qp-signatures"><span>أعدّه: __________________</span><span>راجعه: __________________</span><span>اعتمده: __________________</span></div>${qatraFooter(data)}</article>`;
}

function css(paper){
  const thermal=paper==='58MM'||paper==='80MM';
  const width=paper==='58MM'?'58mm':paper==='80MM'?'80mm':'auto';
  const page=paper==='A4'?'A4 portrait':paper==='A5'?'A5 portrait':`${width} auto`;
  const margin=thermal?'0':'5mm';
  return `@page{size:${page};margin:${margin}}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#172b3a;font-family:Tahoma,Arial,sans-serif;direction:rtl;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{${thermal?`width:${width};max-width:${width};padding:${paper==='58MM'?'2mm':'2.8mm'}`:'padding:0'}}.qp-document{position:relative;margin:0 auto;background:#fff;border:1.4px solid #14799f;border-radius:10px;padding:${thermal?'1.4mm':'5mm'} ${thermal?'1.5mm':'5mm'} ${thermal?'2mm':'17mm'};break-inside:avoid;page-break-inside:avoid;overflow:hidden;${paper==='A5'?'min-height:198mm;max-height:198mm':paper==='A4'?'min-height:281mm':''}}.qp-brand{display:flex;align-items:center;justify-content:center;gap:${thermal?'2mm':'4mm'};text-align:right;border-bottom:1px solid #9cc7d6;padding-bottom:${thermal?'1.2mm':'3mm'}}.qp-brand img{width:${thermal?'15mm':'20mm'};height:${thermal?'15mm':'20mm'};object-fit:contain}.qp-brand h1{margin:0;color:#0b6f91;font-size:${thermal?'13px':'20px'}}.qp-brand p,.qp-brand small{display:block;margin:2px 0 0;color:#52667a;font-size:${thermal?'8px':'10px'}}.qp-title{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:${thermal?'1.5mm 0':'3mm 0'}}.qp-title h2{margin:0;font-size:${thermal?'13px':'18px'};color:#102a43}.qp-title>span{direction:ltr;unicode-bidi:isolate;font-weight:700;font-size:${thermal?'8px':'10px'}}.qp-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:${thermal?'1mm':'2mm'}}.qp-field{border:1px solid #bdd4df;border-radius:6px;padding:${thermal?'1mm':'2.2mm'};min-width:0}.qp-field.wide{grid-column:1/-1}.qp-field span,.qp-amount span,.qp-finance span,.qp-metrics span,.qp-words span,.qp-note span,.qp-balance-grid span,.qp-summary span{display:block;color:#537085;font-size:${thermal?'7.5px':'9px'};margin-bottom:2px}.qp-field b{display:block;overflow-wrap:anywhere;font-size:${thermal?'9px':'11px'}}.ltr{direction:ltr;unicode-bidi:isolate}.qp-amount{border:2px solid #0b6f91;border-radius:8px;text-align:center;padding:${thermal?'1.8mm':'4mm'};margin:${thermal?'1.5mm 0':'3mm 0'}}.qp-amount b{display:block;font-size:${thermal?'16px':'25px'};color:#075985}.qp-balance-grid,.qp-finance,.qp-metrics,.qp-summary{display:grid;grid-template-columns:repeat(${thermal?'1':'3'},minmax(0,1fr));gap:${thermal?'1mm':'2mm'}}.qp-balance-grid>div,.qp-finance>div,.qp-metrics>div,.qp-summary>div{border:1px solid #bdd4df;border-radius:6px;padding:${thermal?'1mm':'2.4mm'};text-align:center}.qp-balance-grid .due,.qp-finance .remaining{border-color:#dc7b7b;background:#fff7f7}.qp-balance-grid .credit{border-color:#66b79d;background:#f1fff9}.qp-finance .total{border:2px solid #0b6f91;background:#f2fbff}.qp-section{margin-top:${thermal?'1.5mm':'3mm'}}.qp-section h3{margin:0 0 2mm;color:#fff;background:#14799f;border-radius:5px;padding:${thermal?'1mm':'1.7mm 2mm'};font-size:${thermal?'9px':'11px'}}.qp-finance{grid-template-columns:repeat(3,minmax(0,1fr))}.qp-words,.qp-note,.qp-cert{margin-top:${thermal?'1.2mm':'2.5mm'};border:1px solid #bdd4df;border-radius:6px;padding:${thermal?'1mm':'2mm'};text-align:center;font-size:${thermal?'8px':'10px'}}.qp-words b,.qp-note b{font-size:${thermal?'8px':'10px'}}.qatra-qr{text-align:center;margin:${thermal?'1.5mm':'3mm'} auto}.qatra-qr img{width:${thermal?(paper==='58MM'?'24mm':'28mm'):'27mm'}!important;height:${thermal?(paper==='58MM'?'24mm':'28mm'):'27mm'}!important}.qatra-qr figcaption{font-size:${thermal?'7px':'8px'}}.qp-signatures{display:flex;justify-content:space-between;gap:8px;margin-top:${thermal?'2mm':'5mm'};font-size:${thermal?'8px':'10px'}}.qp-system-footer{${thermal?'margin-top:2mm;padding-top:1mm;border-top:1px solid #aab8c2':'position:absolute;right:4mm;left:4mm;bottom:2mm;padding-top:1mm;border-top:1px solid #aab8c2'};display:flex;align-items:center;justify-content:space-between;gap:5px;font-size:${thermal?'7px':'8px'};color:#52667a}.qp-system-mark{display:flex;align-items:center;gap:1mm}.qp-system-mark img{width:${thermal?'5mm':'7mm'};height:${thermal?'5mm':'7mm'};object-fit:contain}.qp-system-mark small{display:block}.qp-report table{width:100%;border-collapse:collapse;margin-top:3mm}.qp-report th,.qp-report td{border:1px solid #8daaba;padding:2mm;font-size:9px;text-align:right}.qp-report th{background:#eaf6fb;color:#164e63}.qp-report .qp-title{border-bottom:1px solid #bdd4df}.qp-voucher.incoming .qp-amount{border-color:#0f766e}.qp-voucher.outgoing .qp-amount{border-color:#b45309}.qp-voucher.outgoing .qp-amount b{color:#9a3412}${thermal?'.qp-document{border:0;border-radius:0}.qp-title{display:block;text-align:center}.qp-title>span{display:block;margin-top:1mm}.qp-finance,.qp-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.qp-system-footer{display:block;text-align:center}.qp-system-mark{justify-content:center;margin-top:1mm}':''}`;
}

function fragment(options){
  const type=String(options?.type||'RECEIPT').toUpperCase(),paper=paperToken(options?.paper),data=options?.data||{},thermal=paper==='58MM'||paper==='80MM';
  const body=type==='INVOICE'?invoice(data):type==='VOUCHER'?voucher(data):type==='REPORT'?report(data):receipt(data,thermal);
  return `<style>${css(paper)}</style>${body}`;
}

function documentHtml(options){
  const paper=paperToken(options?.paper),title=options?.title||options?.data?.title||'Qatra Pro';
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>${css(paper)}</style></head><body>${fragment({...options,paper}).replace(/^<style>[\s\S]*?<\/style>/,'')}</body></html>`;
}

function print(options){
  const paper=paperToken(options?.paper),title=options?.title||options?.data?.number||options?.data?.title||'Qatra Pro',html=documentHtml({...options,paper});
  try{if(global.AndroidBridge&&typeof global.AndroidBridge.printHtml==='function'){global.AndroidBridge.printHtml(String(title),html,paper);return true;}}catch(_){}
  const win=global.open('','_blank');
  if(!win){alert('تعذر فتح نافذة الطباعة. اسمح بالنوافذ المنبثقة ثم حاول مرة أخرى.');return false;}
  win.document.write(html.replace('</body>','<script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body>'));
  win.document.close();
  return true;
}

function closePreview(){document.querySelector('.qatra-print-preview-overlay')?.remove();document.body.style.overflow='';}
function preview(options){
  closePreview();
  const overlay=document.createElement('div');
  overlay.className='qatra-print-preview-overlay';
  overlay.innerHTML='<div class="qatra-print-preview-sheet"><div class="qatra-print-preview-head"><h3></h3><div class="qatra-print-preview-actions"><button type="button" class="print">طباعة الآن</button><button type="button" class="close">إغلاق</button></div></div><iframe class="qatra-print-preview-frame" title="معاينة الوثيقة"></iframe></div>';
  overlay.querySelector('h3').textContent=options?.title||options?.data?.title||'معاينة الوثيقة';
  overlay.querySelector('.close').addEventListener('click',closePreview);
  overlay.addEventListener('click',event=>{if(event.target===overlay)closePreview();});
  overlay.querySelector('.print').addEventListener('click',()=>print(options));
  overlay.querySelector('iframe').srcdoc=documentHtml(options);
  document.body.appendChild(overlay);document.body.style.overflow='hidden';
}

global.QatraPrint={fragment,documentHtml,print,preview,closePreview,money,number,formatNumber};
})(window);
