/* Qatra Pro: one role-aware synchronization entry point for all four applications. */
(function(global){
'use strict';

const roleConfig={
  admin:{label:'الإدارة',root:'#dashboard',namespace:'admin'},
  reader:{label:'الكاشف',root:'#home',namespace:'reader'},
  collector:{label:'المحصل',root:'#home',namespace:'collector'},
  cashier:{label:'الصندوق',root:'#home',namespace:'cashier'}
};

function detectRole(){
  const body=document.body;
  if(body?.classList.contains('role-admin'))return'admin';
  if(body?.classList.contains('role-reader'))return'reader';
  if(body?.classList.contains('role-collector'))return'collector';
  if(body?.classList.contains('role-cashier'))return'cashier';
  return'';
}

function safeState(namespace){
  try{return global.QatraStore?.load?.(namespace,()=>({}))||{};}catch(_){return{};}
}

function pendingCount(role,state){
  if(role==='reader')return (state.readings||[]).filter(row=>!row.exportedAt&&!row.submittedAt).length;
  if(role==='collector')return (state.payments||[]).filter(row=>!row.exportedAt).length;
  if(role==='cashier')return (state.transactions||[]).filter(row=>!row.exportedAt).length+(state.directPayments||[]).filter(row=>!row.exportedAt).length;
  return 0;
}

function lastUpdate(state){
  const value=state.lastUpdatedAt||state.assignment?.importedAt||state.setup?.importedAt||state.meta?.updatedAt||'';
  if(!value)return'لا يوجد سجل بعد';
  try{return new Intl.DateTimeFormat('ar-YE',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(value));}
  catch(_){return String(value);}
}

function invoke(role){
  if(role==='admin')return global.QatraDriveSync?.open?.();
  if(role==='reader')return global.Reader?.openDriveSync?.();
  if(role==='collector')return global.Collector?.openDriveSync?.();
  if(role==='cashier')return global.Cashier?.openDriveSync?.();
  throw new Error('تعذر تحديد التطبيق الحالي');
}

function build(role){
  const config=roleConfig[role],state=safeState(config.namespace),pending=pendingCount(role,state);
  const card=document.createElement('section');
  card.className='qatra-unified-sync-card no-print';
  card.dataset.qatraUnifiedSync=role;
  card.innerHTML=`<div class="qatra-unified-sync-copy"><small>مركز موحّد وآمن</small><h3>المزامنة الكاملة — ${config.label}</h3><p>يرسل ويستقبل جميع البيانات المسموح بها لهذا الدور فقط، دون كشف بيانات التطبيقات الأخرى.</p><div class="qatra-unified-sync-meta"><span>آخر تحديث: ${lastUpdate(state)}</span>${pending?`<span>بانتظار الإرسال: ${pending}</span>`:'<span>لا توجد عمليات معلقة ظاهرة</span>'}</div></div><button type="button" class="qatra-unified-sync-button">🔄 مزامنة الآن<span>فتح مركز المزامنة</span></button>`;
  const button=card.querySelector('button');
  button.addEventListener('click',()=>{
    const old=button.innerHTML;
    button.disabled=true;
    button.innerHTML='جارٍ تجهيز المزامنة…<span>يرجى عدم إغلاق التطبيق</span>';
    try{invoke(role);}
    catch(error){alert(error?.message||'تعذر فتح مركز المزامنة.');}
    finally{setTimeout(()=>{button.disabled=false;button.innerHTML=old;refresh(role);},900);}
  });
  return card;
}

function insert(role){
  const config=roleConfig[role],root=document.querySelector(config.root);
  if(!root||root.querySelector(`[data-qatra-unified-sync="${role}"]`))return;
  const card=build(role);
  const preferred=root.querySelector('[class*="hero"]');
  if(preferred?.parentNode===root)preferred.insertAdjacentElement('afterend',card);
  else root.insertAdjacentElement('afterbegin',card);
}

function refresh(role){
  document.querySelector(`[data-qatra-unified-sync="${role}"]`)?.remove();
  insert(role);
}

function install(){
  const role=detectRole();
  if(!role)return;
  insert(role);
  const root=document.querySelector(roleConfig[role].root);
  if(root){
    let queued=false;
    new MutationObserver(()=>{
      if(queued)return;
      queued=true;
      setTimeout(()=>{queued=false;insert(role);},0);
    }).observe(root,{childList:true});
  }
}

global.QatraUnifiedSync={open:()=>invoke(detectRole()),refresh:()=>refresh(detectRole()),role:detectRole};
document.addEventListener('DOMContentLoaded',install);
})(window);
