/* Qatra Pro print adapters v2: document-specific headers and one footer brand. */
(function(global){
'use strict';

const n=value=>global.QatraPrint?.number?.(value)||0;
const decode=value=>{try{return decodeURIComponent(String(value??''));}catch(_){return String(value??'');}};
const validPosition=value=>['right','center','left','hidden'].includes(String(value))?String(value):'right';
const validLayout=value=>['formal','compact','minimal'].includes(String(value))?String(value):'formal';
const validColor=value=>/^#[0-9a-f]{6}$/i.test(String(value||''))?String(value):'#0b6f91';

function genericMeta(settings={}){return [settings.projectAddress,settings.projectPhone1,settings.projectAccountNo].filter(Boolean).join(' | ');}
function documentBrand(settings={},kind='receipt'){
  const prefix=kind==='invoice'?'invoice':kind==='report'?'reports':'receipt';
  const title=settings[`${prefix}HeaderTitle`]||settings.projectName||'قطرة برو';
  const subtitle=settings[`${prefix}HeaderSubtitle`]||settings.ownerName||'';
  const meta=settings[`${prefix}HeaderMeta`]||genericMeta(settings);
  const footer=kind==='invoice'?(settings.invoiceFooter||'هذه الفاتورة صادرة من المشروع.'):(kind==='report'?(settings.reportsFooter||'صادر عن نظام قطرة برو'):(settings.receiptFooter||'هذا السند صادر من المشروع.'));
  return {projectName:settings.projectName||title,headerTitle:title,headerSubtitle:subtitle,headerMeta:meta,headerLogoPosition:validPosition(settings[`${prefix}HeaderLogoPosition`]||'right'),headerLayout:validLayout(settings[`${prefix}HeaderLayout`]||'formal'),headerAccentColor:validColor(settings[`${prefix}HeaderAccentColor`]||'#0b6f91'),logo:settings.projectLogo||'',currency:settings.currencyShort||'ر.ي',footer};
}

function balanceParts(value){const amount=n(value);if(amount>0)return{amount,suffix:'عليكم',label:'الرصيد المتبقي عليكم'};if(amount<0)return{amount:Math.abs(amount),suffix:'لكم',label:'الرصيد المتبقي لكم'};return{amount:0,suffix:'',label:'لا يوجد رصيد'};}

function installAdmin(){
  if(!global.YWP||!global.QatraPrint)return;
  if(!global.YWP.__qatraUnifiedPrintPatched){
    const originalPrintWindow=global.YWP.printWindow;
    global.YWP.printWindow=function(title,body,page){const value=String(body||'');const marked=value.includes('qp-brand-footer')&&!value.includes('qatra-print-brand')?`${value}<!-- qatra-print-brand -->`:value;return originalPrintWindow.call(global.YWP,title,marked,page);};
    global.YWP.__qatraUnifiedPrintPatched=true;
  }
  global.YWP.invoiceHtml=function(inv){
    const state=global.YWP.state||{},settings=state.settings||{},subscriber=global.YWP.subscriber(inv.subscriberId)||{},cycle=global.YWP.cycle(inv.cycleId)||{};
    const arrears=Math.max(0,n(inv.prevBalance)),credit=Math.max(0,-n(inv.prevBalance)),total=Math.max(0,n(inv.amount)+arrears-credit),paid=n(inv.paidAmount),remaining=Math.max(0,n(inv.remainingAmount??(total-paid)));
    return global.QatraPrint.fragment({type:'INVOICE',paper:'A5',data:{...documentBrand(settings,'invoice'),title:settings.invoiceTitle||'فاتورة استهلاك مياه',number:inv.no,date:inv.date,cycle:global.YWP.arCycle?.(cycle.type)||'',subscriberName:subscriber.name,subscriberCode:subscriber.code,meterNo:subscriber.meterNo,address:subscriber.address||subscriber.area,previousReading:inv.prevReading,currentReading:inv.currentReading,consumption:inv.consumption,tariff:inv.tariff||settings.tariff,consumptionAmount:inv.amount,arrears,credit,total,paid,remaining,totalWords:global.YWP.moneyWords?.(total)||'',qrText:global.QatraQr?.invoice?.(inv)||''}});
  };
  global.YWP.receiptHtml=function(payment,mode='thermal'){
    const state=global.YWP.state||{},settings=state.settings||{},subscriber=global.YWP.subscriber(payment.subscriberId)||{},current=global.YWP.balance(payment.subscriberId),balance=balanceParts(current),paper=mode==='paper'?'A5':String(settings.receiptThermalWidth||'58')==='80'?'80MM':'58MM';
    return global.QatraPrint.fragment({type:'RECEIPT',paper,data:{...documentBrand(settings,'receipt'),title:settings.receiptTitle||'سند قبض',number:payment.receiptNo,date:payment.date,subscriberName:subscriber.name,subscriberCode:subscriber.code,meterNo:subscriber.meterNo,method:payment.method,collector:payment.collector,amount:payment.amount,note:payment.note,balanceAfter:balance.amount,balanceAfterSuffix:balance.suffix,balanceAfterLabel:balance.label,qrText:global.QatraQr?.receipt?.(payment)||'',certification:settings.receiptFooter||'هذا السند صادر من المشروع.'}});
  };
}

function collectorState(){try{return global.QatraStore?.load?.('collector',()=>({payments:[],preferences:{}}))||{};}catch(_){return{};}}
function collectorDocument(encodedId,paper){
  const state=collectorState(),payment=(state.payments||[]).find(row=>String(row.id)===decode(encodedId));
  if(!payment)throw new Error('تعذر العثور على سند القبض.');
  const settings=state.assignment?.settings||{},before=n(payment.balanceBefore),after=n(payment.balanceAfter),balance=balanceParts(after),brand=documentBrand(settings,'receipt');
  if(!settings.receiptHeaderTitle&&payment.projectName)brand.headerTitle=payment.projectName;
  if(!settings.projectLogo&&payment.projectLogo)brand.logo=payment.projectLogo;
  return {type:'RECEIPT',paper,title:payment.receiptNo,data:{...brand,title:payment.receiptTitle||settings.receiptTitle||'سند قبض',number:payment.receiptNo,date:payment.date,subscriberName:payment.subscriberName,subscriberCode:payment.subscriberCode,meterNo:payment.meterNo,method:payment.method,collector:payment.collectorName,amount:payment.amount,note:payment.note,balanceBefore:Math.abs(before),balanceBeforeSuffix:before>0?'عليكم':before<0?'لكم':'',balanceAfter:balance.amount,balanceAfterSuffix:balance.suffix,balanceAfterLabel:balance.label,qrText:global.QatraQr?.receipt?.(payment)||'',certification:payment.receiptFooter||settings.receiptFooter||'هذا السند صادر من المشروع.',footer:payment.receiptFooter||settings.receiptFooter||brand.footer}};
}
function installCollector(){
  if(!global.Collector||!global.QatraPrint)return;
  const oldPaper=global.Collector.printPaperById,oldThermal=global.Collector.printThermalById,oldPreview=global.Collector.previewThermalById;
  global.Collector.printPaperById=id=>{try{return global.QatraPrint.print(collectorDocument(id,'A5'));}catch(error){alert(error.message);return oldPaper?.(id);}};
  global.Collector.printThermalById=id=>{try{const state=collectorState(),paper=String(state.preferences?.thermalWidth||'80')==='58'?'58MM':'80MM';return global.QatraPrint.print(collectorDocument(id,paper));}catch(error){alert(error.message);return oldThermal?.(id);}};
  global.Collector.previewThermalById=id=>{try{const state=collectorState(),paper=String(state.preferences?.thermalWidth||'80')==='58'?'58MM':'80MM';return global.QatraPrint.preview(collectorDocument(id,paper));}catch(error){alert(error.message);return oldPreview?.(id);}};
}

function cashierState(){try{return global.QatraStore?.load?.('cashier',()=>({transactions:[],directPayments:[]}))||{};}catch(_){return{};}}
function cashierDocument(encodedId,kind){
  const state=cashierState(),id=decode(encodedId),direct=kind==='direct',item=direct?(state.directPayments||[]).find(row=>String(row.id)===id):(state.transactions||[]).find(row=>String(row.id)===id);
  if(!item)throw new Error('تعذر العثور على حركة الصندوق.');
  const settings=state.setup?.settings||{},incoming=direct||['collector_deposit','other_income','opening_adjustment'].includes(item.type);
  return {type:'VOUCHER',paper:'A5',title:item.receiptNo||item.id,data:{...documentBrand(settings,'receipt'),title:incoming?'سند قبض':'سند صرف',direction:incoming?'IN':'OUT',number:item.receiptNo||item.id,date:item.date,party:item.party||item.subscriberName||item.description,method:item.method,reference:item.referenceNo||item.meterNo||'',description:item.description||(direct?'تحصيل مباشر':''),amount:item.amount,note:item.note,currency:settings.currencyShort||'ر.ي',qrText:global.QatraQr?.receipt?.(item)||''}};
}
function installCashier(){
  if(!global.Cashier||!global.QatraPrint)return;
  const oldPrint=global.Cashier.printPaperById,oldPreview=global.Cashier.previewById;
  global.Cashier.printPaperById=(id,kind)=>{try{return global.QatraPrint.print(cashierDocument(id,kind));}catch(error){alert(error.message);return oldPrint?.(id,kind);}};
  global.Cashier.previewById=(id,kind)=>{try{return global.QatraPrint.preview(cashierDocument(id,kind));}catch(error){alert(error.message);return oldPreview?.(id,kind);}};
}

function install(){installAdmin();installCollector();installCashier();}
document.addEventListener('DOMContentLoaded',()=>setTimeout(install,0));
global.QatraPrintIntegration={install,documentBrand};
})(window);
