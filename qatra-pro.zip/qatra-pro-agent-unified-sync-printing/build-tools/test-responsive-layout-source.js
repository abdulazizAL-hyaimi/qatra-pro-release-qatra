'use strict';

const fs = require('fs');
const assert = require('assert');

const read = path => fs.readFileSync(path, 'utf8');
const pages = ['mobile','reader','collector','cashier','manager_users','manager_reader','manager_collectors','manager_cashbox'];
const design = read('app/src/main/assets/qatra/assets/design-v25.css');
const uxCss = read('app/src/main/assets/qatra/assets/ux-v26.css');
const uxJs = read('app/src/main/assets/qatra/assets/ux-v26.js');
const accountingCss = read('app/src/main/assets/qatra/assets/accounting.css');
const accountingJs = read('app/src/main/assets/qatra/assets/accounting.js');

pages.forEach(name => {
  const html = read(`app/src/main/assets/qatra/${name}.html`);
  assert.match(html, /name="viewport"[^>]+width=device-width/,
    `${name}.html must use the device viewport`);
  assert.match(html, /assets\/design-v25\.css/,
    `${name}.html must load the shared responsive design`);
  assert.match(html, /assets\/ux-v26\.css/,
    `${name}.html must load the usability design layer`);
  assert.match(html, /assets\/ux-v26\.js/,
    `${name}.html must load the usability runtime layer`);
});

assert.match(design, /Qatra 2\.5\.5 universal phone fit/);
assert.match(design, /@media screen and \(max-width:600px\)/);
assert.match(design, /@media screen and \(max-width:380px\)/);
assert.match(design, /@media screen and \(max-width:330px\)/);
assert.match(design, /orientation:landscape/);
assert.match(design, /overflow-x:hidden/);
assert.match(design, /100dvh/);
assert.match(design, /env\(safe-area-inset/);
assert.match(design, /\.grid\.two,.grid\.three\{grid-template-columns:minmax\(0,1fr\)!important\}/);
assert.match(design, /\.reader-sheet,.collector-modal-sheet,.cashier-modal-sheet/);
assert.match(design, /\.table-wrap:not\(\.accounting-table-wrap\)\{overflow-x:auto!important/);

for (const token of ['qatra-context-bar','qatra-primary-action','qatra-sticky-actions','qatra-live-consumption','qatra-mobile-cards','qatra-field-error']) {
  assert.ok(uxCss.includes(token), `UX CSS must include ${token}`);
}
assert.match(uxCss, /body\.role-reader[\s\S]{0,160}--ux-role/);
assert.match(uxCss, /body\.role-collector[\s\S]{0,160}--ux-role/);
assert.match(uxCss, /body\.role-cashier[\s\S]{0,160}--ux-role/);
assert.match(uxCss, /@media\(max-width:720px\)[\s\S]{0,4000}table\.qatra-mobile-cards/);

for (const token of ['ensureContextBar','decorateTable','validateInput','liveConsumptionForModal','liveConsumptionForAdmin','addProgressSummary']) {
  assert.ok(uxJs.includes(token), `UX runtime must include ${token}`);
}
assert.match(uxJs, /cell\.dataset\.label=labels\[index\]/,
  'mobile cards must copy visible table headers to data labels');
assert.match(uxJs, /current-previous/,
  'reading forms must calculate the expected consumption live');
assert.doesNotMatch(uxJs, /localStorage|replaceAll/,
  'UX enhancement must not add storage or incompatible String.replaceAll usage');

assert.match(accountingJs, /function decorateAccountingTables/);
assert.match(accountingJs, /cell\.dataset\.label=labels\[index\]/);
assert.match(accountingJs, /class="accounting-responsive-table"/);
assert.match(accountingJs, /decorateAccountingTables\(content\)/);
assert.match(accountingCss, /Phone-first accounting layout/);
assert.match(accountingCss, /\.accounting-responsive-table tbody td::before\{content:attr\(data-label\)/);
assert.match(accountingCss, /\.accounting-responsive-table thead\{position:absolute/);
assert.match(accountingCss, /@media screen and \(max-width:330px\)/);

console.log('Responsive layout and Qatra UX 2.6 source regression test passed.');
