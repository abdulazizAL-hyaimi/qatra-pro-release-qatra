/* Force QATRA PRO branding into the printed footer, never as a floating watermark. */
(function(global){
'use strict';
let installed=false,working=false;
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const STYLE=`<style class="qatra-report-footer-style">.qatra-report-watermark.qatra-report-brand-footer{position:fixed!important;right:4mm!important;left:4mm!important;bottom:2mm!important;z-index:999!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:3mm!important;min-height:8mm!important;padding-top:1mm!important;border-top:.3mm solid #9eb2bd!important;background:#fff!important;opacity:1!important;direction:rtl!important;pointer-events:none!important;color:#52667a!important}.qatra-report-brand-footer .qatra-report-footer-note{max-width:62%!important;font-size:7pt!important;line-height:1.25!important}.qatra-report-brand-footer .qatra-report-footer-brand{display:flex!important;align-items:center!important;gap:1mm!important;direction:ltr!important}.qatra-report-brand-footer .qatra-report-footer-brand>img{width:7mm!important;height:7mm!important;object-fit:contain!important}.qatra-report-brand-footer .qatra-report-footer-brand>span{display:flex!important;flex-direction:column!important;align-items:flex-start!important;line-height:1.1!important}.qatra-report-brand-footer b{font-family:Georgia,"Times New Roman",serif!important;font-size:8pt!important;letter-spacing:.4pt!important}.qatra-report-brand-footer small{font-size:6pt!important;white-space:nowrap!important}.report-document,.accounting-print-document{padding-bottom:13mm!important}</style>`;
function footerHtml(){
  const settings=global.YWP?.state?.settings||{};
  if(settings.reportBrandWatermarkEnabled===false||String(settings.reportBrandWatermarkEnabled)==='false')return'';
  return `<footer class="qatra-report-watermark qatra-print-brand qatra-report-brand-footer"><span class="qatra-report-footer-note">${esc(settings.reportsFooter||'صادر عن نظام قطرة برو')}</span><span class="qatra-report-footer-brand"><img src="assets/qatra-pro-mark.svg" alt=""><span><b>QATRA PRO</b><small>نظام قطرة برو لإدارة خدمات المياه</small></span></span></footer>`;
}
function apply(root){
  if(!root||working||root.querySelector('.qp-brand-footer'))return;
  working=true;
  try{root.querySelectorAll('.qatra-report-watermark,.qatra-print-brand').forEach(node=>node.remove());const footer=footerHtml();if(footer)root.insertAdjacentHTML('beforeend',footer);root.dataset.qatraFooterMode='footer-v1';}finally{working=false;}
}
function current(){apply(document.querySelector('#currentReportHtml'));}
function sanitize(title,body,page){
  const html=String(body||'');
  if(html.includes('qp-brand-footer'))return html;
  const reportLike=/report-document|accounting-print-document|report-table|report-user-header|report-org-header|v13-doc-header/.test(html)||/^A4/i.test(String(page||''));
  if(!reportLike)return html;
  const box=document.createElement('div');box.innerHTML=html;const root=box.querySelector('.report-document,.accounting-print-document')||box;apply(root);return `${STYLE}${box.innerHTML}`;
}
function relabelSettings(){
  document.querySelectorAll('#reportHeaderSettingsCard label').forEach(label=>{
    if(label.textContent.includes('العلامة التجارية'))label.innerHTML=label.innerHTML.replace('إظهار QATRA PRO كعلامة مائية أسفل يسار كل صفحة','إظهار QATRA PRO في تذييل كل صفحة مطبوعة');
    if(label.textContent.includes('شفافية العلامة المائية'))label.closest('.field')?.setAttribute('hidden','hidden');
  });
  const title=document.querySelector('#reportHeaderSettingsCard .report-header-settings-intro p');
  if(title)title.textContent='صمّم ترويسة التقارير، وتظهر علامة QATRA PRO في تذييل الصفحة المطبوعة فقط.';
}
function install(){
  if(!global.YWP||!global.App)return setTimeout(install,200);
  if(!YWP.__qatraFooterOnlyPrint){const previous=YWP.printWindow;YWP.printWindow=function(title,body,page){return previous(title,sanitize(title,body,page),page);};YWP.__qatraFooterOnlyPrint=true;}
  if(!installed){const observer=new MutationObserver(()=>setTimeout(()=>{current();relabelSettings();},0));observer.observe(document.body,{childList:true,subtree:true});installed=true;}
  current();relabelSettings();
}
global.QatraPrintBrandFooter={install,apply,sanitize,footerHtml};
install();global.addEventListener('load',()=>setTimeout(install,80));
})(window);
