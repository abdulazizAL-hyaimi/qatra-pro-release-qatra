package com.qatra.pro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Native persistence boundary for every WebView role.
 *
 * The UI keeps its existing JSON domain model, while this class stores the canonical state in
 * SQLite and maintains a searchable record index. Synchronization metadata is committed in the
 * same transaction as imported state so a power loss cannot apply the same package twice.
 */
public final class QatraDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "qatra-pro-secure.db";
    private static final int DATABASE_VERSION = 3;
    private static final Set<String> INDEXED_ARRAYS = new HashSet<>(Arrays.asList(
            "subscribers", "cycles", "readings", "invoices", "payments", "expenses",
            "transactions", "directPayments", "cashboxTransactions", "cashboxDirectPayments",
            "receipts", "exports", "audit", "confirmations", "users"
    ));

    public QatraDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE app_state (" +
                "namespace TEXT PRIMARY KEY NOT NULL," +
                "payload_json TEXT NOT NULL," +
                "updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE records (" +
                "namespace TEXT NOT NULL," +
                "entity_type TEXT NOT NULL," +
                "entity_id TEXT NOT NULL," +
                "payload_json TEXT NOT NULL," +
                "updated_at INTEGER NOT NULL," +
                "sync_status TEXT NOT NULL DEFAULT 'LOCAL'," +
                "PRIMARY KEY(namespace, entity_type, entity_id))");
        db.execSQL("CREATE INDEX idx_records_type ON records(namespace, entity_type, updated_at)");
        db.execSQL("CREATE TABLE sync_packages (" +
                "package_id TEXT PRIMARY KEY NOT NULL," +
                "operation_id TEXT NOT NULL UNIQUE," +
                "direction TEXT NOT NULL," +
                "sender_role TEXT NOT NULL," +
                "target_role TEXT NOT NULL," +
                "operation_type TEXT NOT NULL," +
                "payload_hash TEXT NOT NULL," +
                "status TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "processed_at INTEGER)");
        db.execSQL("CREATE INDEX idx_sync_status ON sync_packages(direction, status, created_at)");
        db.execSQL("CREATE TABLE confirmations (" +
                "confirmation_id TEXT PRIMARY KEY NOT NULL," +
                "package_id TEXT NOT NULL UNIQUE," +
                "operation_id TEXT NOT NULL," +
                "payload_hash TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(package_id) REFERENCES sync_packages(package_id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE migration_log (" +
                "namespace TEXT PRIMARY KEY NOT NULL," +
                "legacy_key TEXT NOT NULL," +
                "payload_hash TEXT NOT NULL," +
                "migrated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE audit_log (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "event_type TEXT NOT NULL," +
                "details TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");
        createRelationalSchema(db);
        createBusinessRuleSchema(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            try {
                createRelationalSchema(db);
                backfillRelationalState(db);
                audit(db, "RELATIONAL_SCHEMA_MIGRATED", "v" + oldVersion + "->v2");
            } catch (Exception e) {
                throw new IllegalStateException("تعذر ترحيل قاعدة البيانات العلائقية", e);
            }
        }
        if (oldVersion < 3) {
            try {
                ensureColumn(db, "qatra_meter_readings", "meter_changed",
                        "INTEGER NOT NULL DEFAULT 0");
                db.execSQL("UPDATE qatra_meter_readings SET meter_changed=1 " +
                        "WHERE payload_json LIKE '%\"meterChangeId\"%'");
                createBusinessRuleSchema(db);
                audit(db, "BUSINESS_RULES_MIGRATED", "v" + oldVersion + "->v3");
            } catch (Exception e) {
                throw new IllegalStateException(
                        "تعذر تطبيق قيود التفرد والقراءات على قاعدة البيانات", e);
            }
        }
    }

    public synchronized String getState(String namespace) {
        validateNamespace(namespace);
        try (Cursor c = getReadableDatabase().query(
                "app_state", new String[]{"payload_json"}, "namespace=?",
                new String[]{namespace}, null, null, null, "1")) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    public synchronized void saveState(String namespace, String payloadJson) throws Exception {
        validateState(namespace, payloadJson);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            saveStateInTransaction(db, namespace, payloadJson, "LOCAL");
            audit(db, "STATE_SAVED", namespace);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    /** Builds a complete role-scoped snapshot for a password-protected portable backup. */
    public synchronized JSONObject exportPortableBackup(String role, String primaryOverrideJson) throws Exception {
        String primary = primaryNamespaceForRole(role);
        java.util.List<String> portableNamespaces = portableNamespacesForRole(role);
        JSONObject namespaces = new JSONObject();
        for (String namespace : portableNamespaces) {
            String payload = namespace.equals(primary) && primaryOverrideJson != null
                    && !primaryOverrideJson.trim().isEmpty()
                    ? primaryOverrideJson : getState(namespace);
            if (payload == null || payload.trim().isEmpty()) continue;
            validateState(namespace, payload);
            namespaces.put(namespace, new JSONObject(payload));
        }
        if (!namespaces.has(primary)) {
            throw new SecurityException("لا توجد بيانات تشغيل محفوظة لإنشاء النسخة الاحتياطية");
        }
        JSONObject meta = new JSONObject();
        meta.put("type", "QATRA_PORTABLE_DATABASE_BACKUP");
        meta.put("version", 2);
        meta.put("role", role);
        meta.put("exportedAt", System.currentTimeMillis());
        meta.put("namespaceCount", namespaces.length());
        JSONObject payload = new JSONObject();
        payload.put("meta", meta);
        payload.put("namespaces", namespaces);
        payload.put("relationalSync", exportRelationalSyncState(portableNamespaces));
        return payload;
    }

    /** Restores all allowed namespaces together so interruption cannot leave a partial backup. */
    public synchronized void restorePortableBackup(String role, String payloadJson) throws Exception {
        JSONObject payload = new JSONObject(payloadJson == null ? "{}" : payloadJson);
        JSONObject meta = payload.optJSONObject("meta");
        JSONObject namespaces = payload.optJSONObject("namespaces");
        if (meta == null || namespaces == null
                || !"QATRA_PORTABLE_DATABASE_BACKUP".equals(meta.optString("type"))
                || meta.optInt("version") != 2 || !role.equals(meta.optString("role"))) {
            throw new SecurityException("محتوى النسخة الاحتياطية لا يطابق هذا التطبيق");
        }
        String primary = primaryNamespaceForRole(role);
        Set<String> allowed = new HashSet<>(portableNamespacesForRole(role));
        JSONArray names = namespaces.names();
        if (names == null || !namespaces.has(primary)) {
            throw new SecurityException("النسخة الاحتياطية لا تحتوي على بيانات التشغيل الأساسية");
        }
        for (int i = 0; i < names.length(); i++) {
            String namespace = names.optString(i, "");
            if (!allowed.contains(namespace) || namespaces.optJSONObject(namespace) == null) {
                throw new SecurityException("تحتوي النسخة على نطاق بيانات غير مسموح");
            }
        }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            JSONObject relationalSync = payload.optJSONObject("relationalSync");
            if (relationalSync != null) restoreRelationalSyncState(db, relationalSync, allowed);
            for (String namespace : portableNamespacesForRole(role)) {
                JSONObject incoming = namespaces.optJSONObject(namespace);
                if (incoming == null) continue;
                JSONObject protectedState = preserveOperationalStart(db, namespace, incoming);
                validateState(namespace, protectedState.toString());
                saveStateInTransaction(db, namespace, protectedState.toString(), "BACKUP_RESTORED");
            }
            audit(db, "PORTABLE_BACKUP_RESTORED", role + ":" + meta.optLong("exportedAt", 0L));
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public synchronized boolean migrateLegacyState(String namespace, String legacyKey, String payloadJson) throws Exception {
        validateState(namespace, payloadJson);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (hasState(db, namespace) || hasMigration(db, namespace)) {
                db.setTransactionSuccessful();
                return false;
            }
            saveStateInTransaction(db, namespace, payloadJson, "MIGRATED");
            ContentValues values = new ContentValues();
            values.put("namespace", namespace);
            values.put("legacy_key", legacyKey == null ? "" : legacyKey);
            values.put("payload_hash", sha256(payloadJson));
            values.put("migrated_at", System.currentTimeMillis());
            db.insertOrThrow("migration_log", null, values);
            audit(db, "LEGACY_MIGRATED", namespace);
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    public synchronized boolean isProcessed(String packageId, String operationId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT 1 FROM sync_packages WHERE (package_id=? OR operation_id=?) AND status='PROCESSED' LIMIT 1",
                new String[]{safe(packageId), safe(operationId)})) {
            return c.moveToFirst();
        }
    }

    public synchronized void recordIncomingPending(
            String packageId, String operationId, String senderRole, String targetRole,
            String operationType, String payloadHash) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = syncValues(packageId, operationId, "IN", senderRole, targetRole,
                operationType, payloadHash, "PENDING");
        db.insertWithOnConflict("sync_packages", null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public synchronized void recordOutgoing(
            String packageId, String operationId, String senderRole, String targetRole,
            String operationType, String payloadHash) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = syncValues(packageId, operationId, "OUT", senderRole, targetRole,
                operationType, payloadHash, "EXPORTED");
        db.insertWithOnConflict("sync_packages", null, values, SQLiteDatabase.CONFLICT_IGNORE);
        audit(db, "SYNC_EXPORTED", packageId + ":" + operationType);
    }

    /** Returns a stable confirmation id, or null when the package was already committed. */
    public synchronized String commitImportedState(
            String namespace, String packageId, String operationId, String senderRole,
            String targetRole, String operationType, String payloadHash, String mergedStateJson) throws Exception {
        validateState(namespace, mergedStateJson);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (isProcessedInTransaction(db, packageId, operationId)) {
                db.setTransactionSuccessful();
                return null;
            }

            ContentValues pending = syncValues(packageId, operationId, "IN", senderRole, targetRole,
                    operationType, payloadHash, "PENDING");
            db.insertWithOnConflict("sync_packages", null, pending, SQLiteDatabase.CONFLICT_IGNORE);

            saveStateInTransaction(db, namespace, mergedStateJson, "IMPORTED");
            ContentValues processed = new ContentValues();
            processed.put("status", "PROCESSED");
            processed.put("processed_at", System.currentTimeMillis());
            int updated = db.update("sync_packages", processed,
                    "package_id=? AND operation_id=? AND payload_hash=?",
                    new String[]{packageId, operationId, payloadHash});
            if (updated != 1) throw new IllegalStateException("تعذر تثبيت عملية المزامنة");

            String confirmationId = "CONF-" + UUID.randomUUID();
            ContentValues confirmation = new ContentValues();
            confirmation.put("confirmation_id", confirmationId);
            confirmation.put("package_id", packageId);
            confirmation.put("operation_id", operationId);
            confirmation.put("payload_hash", payloadHash);
            confirmation.put("created_at", System.currentTimeMillis());
            db.insertOrThrow("confirmations", null, confirmation);
            audit(db, "SYNC_COMMITTED", packageId + ":" + operationType);
            db.setTransactionSuccessful();
            return confirmationId;
        } finally {
            db.endTransaction();
        }
    }

    /** Commits a received confirmation and acknowledges the matching outgoing package. */
    public synchronized boolean commitConfirmationReceipt(
            String confirmationPackageId, String confirmationOperationId, String senderRole,
            String targetRole, String payloadHash, String originalPackageId,
            String originalOperationId, String originalPayloadHash) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (isProcessedInTransaction(db, confirmationPackageId, confirmationOperationId)) {
                db.setTransactionSuccessful();
                return false;
            }
            ContentValues incoming = syncValues(confirmationPackageId, confirmationOperationId,
                    "IN", senderRole, targetRole, "CONFIRMATION", payloadHash, "PROCESSED");
            incoming.put("processed_at", System.currentTimeMillis());
            long inserted = db.insertWithOnConflict(
                    "sync_packages", null, incoming, SQLiteDatabase.CONFLICT_IGNORE);
            if (inserted == -1L) {
                ContentValues processed = new ContentValues();
                processed.put("status", "PROCESSED");
                processed.put("processed_at", System.currentTimeMillis());
                int confirmationUpdated = db.update("sync_packages", processed,
                        "package_id=? AND operation_id=? AND payload_hash=? AND direction='IN'",
                        new String[]{confirmationPackageId, confirmationOperationId, payloadHash});
                if (confirmationUpdated != 1) {
                    throw new SecurityException("تعارض في هوية ملف التأكيد؛ لم تُعدّل أي بيانات");
                }
            }

            ContentValues acknowledged = new ContentValues();
            acknowledged.put("status", "ACKNOWLEDGED");
            acknowledged.put("processed_at", System.currentTimeMillis());
            int updated = db.update("sync_packages", acknowledged,
                    "package_id=? AND operation_id=? AND payload_hash=? AND direction='OUT'",
                    new String[]{originalPackageId, originalOperationId, originalPayloadHash});
            if (updated != 1) throw new SecurityException("لا توجد عملية صادرة مطابقة لملف التأكيد");
            audit(db, "SYNC_ACKNOWLEDGED", originalPackageId);
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    public synchronized JSONObject diagnostics() throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONObject out = new JSONObject();
        out.put("states", count(db, "app_state"));
        out.put("records", count(db, "records"));
        out.put("syncPackages", count(db, "sync_packages"));
        out.put("confirmations", count(db, "confirmations"));
        out.put("migrations", count(db, "migration_log"));
        out.put("subscribers", count(db, "qatra_subscribers"));
        out.put("cycles", count(db, "qatra_billing_cycles"));
        out.put("readings", count(db, "qatra_meter_readings"));
        out.put("invoices", count(db, "qatra_invoices"));
        out.put("payments", count(db, "qatra_payments"));
        out.put("expenses", count(db, "qatra_expenses"));
        out.put("accountingChangesPending", countWhere(
                db, "qatra_sync_outbox", "status IN('PENDING','FAILED')"));
        out.put("databaseVersion", db.getVersion());
        try (Cursor c = db.rawQuery("PRAGMA quick_check(1)", null)) {
            out.put("integrity", c.moveToFirst() ? c.getString(0) : "unknown");
        }
        return out;
    }

    private void saveStateInTransaction(
            SQLiteDatabase db, String namespace, String payloadJson, String syncStatus) throws Exception {
        JSONObject root = new JSONObject(payloadJson);
        long now = System.currentTimeMillis();
        ContentValues state = new ContentValues();
        state.put("namespace", namespace);
        state.put("payload_json", root.toString());
        state.put("updated_at", now);
        db.insertWithOnConflict("app_state", null, state, SQLiteDatabase.CONFLICT_REPLACE);

        db.delete("records", "namespace=?", new String[]{namespace});
        JSONArray names = root.names();
        if (names != null) {
            for (int i = 0; i < names.length(); i++) {
                String entityType = names.optString(i, "");
                if (!INDEXED_ARRAYS.contains(entityType)) continue;
                JSONArray rows = root.optJSONArray(entityType);
                if (rows == null) continue;
                for (int j = 0; j < rows.length(); j++) {
                    JSONObject row = rows.optJSONObject(j);
                    if (row == null) continue;
                    String entityId = chooseId(row, entityType, j);
                    ContentValues record = new ContentValues();
                    record.put("namespace", namespace);
                    record.put("entity_type", entityType);
                    record.put("entity_id", entityId);
                    record.put("payload_json", row.toString());
                    record.put("updated_at", now);
                    record.put("sync_status", syncStatus);
                    db.insertWithOnConflict("records", null, record, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }
        }
        projectRelationalState(db, namespace, root, syncStatus, now);
    }

    /**
     * Row-level changes prepared for the future accounting-system connector. The caller sends
     * them in local_sequence order and acknowledges only operation ids accepted by the server.
     */
    public synchronized JSONArray pendingAccountingChanges(int requestedLimit) throws Exception {
        int limit = Math.max(1, Math.min(requestedLimit, 500));
        JSONArray rows = new JSONArray();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT local_sequence,operation_id,namespace,entity_type,entity_id,action," +
                        "payload_json,payload_hash,entity_version,source,created_at FROM qatra_sync_outbox " +
                        "WHERE status IN('PENDING','FAILED') ORDER BY local_sequence LIMIT ?",
                new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("localSequence", c.getLong(0));
                row.put("operationId", c.getString(1));
                row.put("namespace", c.getString(2));
                row.put("entityType", c.getString(3));
                row.put("entityId", c.getString(4));
                row.put("action", c.getString(5));
                row.put("payload", new JSONObject(c.getString(6)));
                row.put("payloadHash", c.getString(7));
                row.put("entityVersion", c.getLong(8));
                row.put("source", c.getString(9));
                row.put("createdAt", c.getLong(10));
                rows.put(row);
            }
        }
        return rows;
    }

    public synchronized int acknowledgeAccountingChanges(JSONArray operationIds) {
        if (operationIds == null || operationIds.length() == 0) return 0;
        SQLiteDatabase db = getWritableDatabase();
        int acknowledged = 0;
        db.beginTransaction();
        try {
            for (int i = 0; i < operationIds.length(); i++) {
                String id = operationIds.optString(i, "").trim();
                if (id.isEmpty()) continue;
                ContentValues values = new ContentValues();
                values.put("status", "ACKNOWLEDGED");
                values.put("acknowledged_at", System.currentTimeMillis());
                acknowledged += db.update("qatra_sync_outbox", values,
                        "operation_id=? AND status IN('PENDING','FAILED')", new String[]{id});
            }
            db.execSQL("DELETE FROM qatra_sync_outbox WHERE status='ACKNOWLEDGED' AND local_sequence NOT IN " +
                    "(SELECT local_sequence FROM qatra_sync_outbox WHERE status='ACKNOWLEDGED' " +
                    "ORDER BY local_sequence DESC LIMIT 5000)");
            audit(db, "ACCOUNTING_CHANGES_ACKNOWLEDGED", String.valueOf(acknowledged));
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return acknowledged;
    }

    private JSONObject exportRelationalSyncState(java.util.List<String> namespaces) throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONObject result = new JSONObject();
        result.put("version", 1);
        JSONArray versions = new JSONArray();
        JSONArray outbox = new JSONArray();
        for (String namespace : namespaces) {
            try (Cursor c = db.rawQuery(
                    "SELECT entity_type,entity_id,entity_version,payload_hash,is_deleted,updated_at " +
                            "FROM qatra_entity_versions WHERE namespace=?",
                    new String[]{namespace})) {
                while (c.moveToNext()) {
                    JSONObject row = new JSONObject();
                    row.put("namespace", namespace);
                    row.put("entityType", c.getString(0));
                    row.put("entityId", c.getString(1));
                    row.put("entityVersion", c.getLong(2));
                    row.put("payloadHash", c.getString(3));
                    row.put("deleted", c.getInt(4) != 0);
                    row.put("updatedAt", c.getLong(5));
                    versions.put(row);
                }
            }
            try (Cursor c = db.rawQuery(
                    "SELECT operation_id,entity_type,entity_id,action,payload_json,payload_hash," +
                            "entity_version,source,created_at FROM qatra_sync_outbox " +
                            "WHERE namespace=? AND status IN('PENDING','FAILED') ORDER BY local_sequence",
                    new String[]{namespace})) {
                while (c.moveToNext()) {
                    JSONObject row = new JSONObject();
                    row.put("operationId", c.getString(0));
                    row.put("namespace", namespace);
                    row.put("entityType", c.getString(1));
                    row.put("entityId", c.getString(2));
                    row.put("action", c.getString(3));
                    row.put("payload", new JSONObject(c.getString(4)));
                    row.put("payloadHash", c.getString(5));
                    row.put("entityVersion", c.getLong(6));
                    row.put("source", c.getString(7));
                    row.put("createdAt", c.getLong(8));
                    outbox.put(row);
                }
            }
        }
        result.put("entityVersions", versions);
        result.put("pendingChanges", outbox);
        return result;
    }

    private static void restoreRelationalSyncState(
            SQLiteDatabase db, JSONObject sync, Set<String> allowedNamespaces) throws Exception {
        if (sync.optInt("version", 0) != 1) {
            throw new SecurityException("إصدار بيانات المزامنة في النسخة الاحتياطية غير مدعوم");
        }
        JSONArray versions = sync.optJSONArray("entityVersions");
        JSONArray pending = sync.optJSONArray("pendingChanges");
        if (versions == null || pending == null) {
            throw new SecurityException("بيانات المزامنة في النسخة الاحتياطية ناقصة");
        }

        for (int i = 0; i < versions.length(); i++) {
            JSONObject row = versions.optJSONObject(i);
            if (row == null) throw new SecurityException("سجل إصدار غير صالح في النسخة الاحتياطية");
            String namespace = row.optString("namespace", "");
            String entityType = row.optString("entityType", "");
            String entityId = row.optString("entityId", "");
            long version = row.optLong("entityVersion", 0L);
            String hash = row.optString("payloadHash", "");
            validateRestoredSyncIdentity(allowedNamespaces, namespace, entityType, entityId, version, hash);
            VersionState current = versionState(db, namespace, entityType, entityId);
            if (current == null || version > current.version) {
                saveVersionState(db, namespace, entityType, entityId, version, hash,
                        row.optBoolean("deleted", false),
                        Math.max(0L, row.optLong("updatedAt", System.currentTimeMillis())));
            }
        }

        for (int i = 0; i < pending.length(); i++) {
            JSONObject row = pending.optJSONObject(i);
            if (row == null) throw new SecurityException("حركة مزامنة غير صالحة في النسخة الاحتياطية");
            String operationId = row.optString("operationId", "");
            try { UUID.fromString(operationId); }
            catch (Exception e) { throw new SecurityException("معرّف حركة المزامنة غير صالح"); }
            String namespace = row.optString("namespace", "");
            String entityType = row.optString("entityType", "");
            String entityId = row.optString("entityId", "");
            String action = row.optString("action", "");
            long version = row.optLong("entityVersion", 0L);
            String hash = row.optString("payloadHash", "");
            validateRestoredSyncIdentity(allowedNamespaces, namespace, entityType, entityId, version, hash);
            if (!"UPSERT".equals(action) && !"DELETE".equals(action)) {
                throw new SecurityException("نوع حركة المزامنة غير صالح");
            }
            JSONObject payload = row.optJSONObject("payload");
            if (payload == null || !hash.equals(sha256(payload.toString()))) {
                throw new SecurityException("بصمة حركة المزامنة لا تطابق محتواها");
            }
            VersionState current = versionState(db, namespace, entityType, entityId);
            if (current != null && (version < current.version
                    || (version == current.version && !hash.equals(current.payloadHash)))) continue;

            ContentValues change = new ContentValues();
            change.put("operation_id", operationId);
            change.put("namespace", namespace);
            change.put("entity_type", entityType);
            change.put("entity_id", entityId);
            change.put("action", action);
            change.put("payload_json", payload.toString());
            change.put("payload_hash", hash);
            change.put("entity_version", version);
            change.put("source", row.optString("source", "BACKUP_RESTORED"));
            change.put("status", "PENDING");
            change.put("created_at", Math.max(0L, row.optLong("createdAt", System.currentTimeMillis())));
            db.insertWithOnConflict(
                    "qatra_sync_outbox", null, change, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }

    private static void validateRestoredSyncIdentity(
            Set<String> allowedNamespaces, String namespace, String entityType,
            String entityId, long version, String payloadHash) {
        validateNamespace(namespace);
        if (!allowedNamespaces.contains(namespace)
                || entityType == null || !entityType.matches("[A-Z_]{2,64}")
                || entityId == null || entityId.isEmpty() || entityId.length() > 256
                || version <= 0L
                || payloadHash == null || !payloadHash.matches("[a-f0-9]{64}")) {
            throw new SecurityException("هوية سجل المزامنة في النسخة الاحتياطية غير صالحة");
        }
    }

    private static void createRelationalSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_profiles(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "project_name TEXT NOT NULL DEFAULT '',owner_name TEXT NOT NULL DEFAULT ''," +
                "account_no TEXT NOT NULL DEFAULT '',currency TEXT NOT NULL DEFAULT ''," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_staff_users(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "username TEXT NOT NULL DEFAULT '',display_name TEXT NOT NULL DEFAULT ''," +
                "role TEXT NOT NULL DEFAULT '',employee_code TEXT NOT NULL DEFAULT ''," +
                "active INTEGER NOT NULL DEFAULT 1," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_subscribers(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "subscriber_code TEXT NOT NULL DEFAULT '',meter_no TEXT NOT NULL DEFAULT ''," +
                "full_name TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT ''," +
                "area TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT ''," +
                "reading_group TEXT NOT NULL DEFAULT '',opening_reading REAL NOT NULL DEFAULT 0," +
                "opening_arrears REAL NOT NULL DEFAULT 0,opening_credit REAL NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_billing_cycles(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "cycle_date TEXT NOT NULL DEFAULT '',cycle_type TEXT NOT NULL DEFAULT ''," +
                "status TEXT NOT NULL DEFAULT '',main_previous REAL NOT NULL DEFAULT 0," +
                "main_current REAL NOT NULL DEFAULT 0,closed_at TEXT NOT NULL DEFAULT ''," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_meter_readings(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "cycle_id TEXT NOT NULL DEFAULT '',subscriber_id TEXT NOT NULL DEFAULT ''," +
                "previous_reading REAL NOT NULL DEFAULT 0,current_reading REAL NOT NULL DEFAULT 0," +
                "consumption REAL NOT NULL DEFAULT 0,reader_id TEXT NOT NULL DEFAULT ''," +
                "assignment_id TEXT NOT NULL DEFAULT '',meter_changed INTEGER NOT NULL DEFAULT 0," +
                "has_attachment INTEGER NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_invoices(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "invoice_no TEXT NOT NULL DEFAULT '',cycle_id TEXT NOT NULL DEFAULT ''," +
                "subscriber_id TEXT NOT NULL DEFAULT '',invoice_date TEXT NOT NULL DEFAULT ''," +
                "amount REAL NOT NULL DEFAULT 0,paid_amount REAL NOT NULL DEFAULT 0," +
                "remaining_amount REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT ''," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_payments(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "receipt_no TEXT NOT NULL DEFAULT '',subscriber_id TEXT NOT NULL DEFAULT ''," +
                "invoice_id TEXT NOT NULL DEFAULT '',payment_date TEXT NOT NULL DEFAULT ''," +
                "amount REAL NOT NULL DEFAULT 0,method TEXT NOT NULL DEFAULT ''," +
                "collector_id TEXT NOT NULL DEFAULT '',income_type TEXT NOT NULL DEFAULT ''," +
                "confirmed INTEGER NOT NULL DEFAULT 1,has_attachment INTEGER NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_expenses(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "expense_date TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT ''," +
                "description TEXT NOT NULL DEFAULT '',amount REAL NOT NULL DEFAULT 0," +
                "payee TEXT NOT NULL DEFAULT '',reference_no TEXT NOT NULL DEFAULT ''," +
                "payment_account TEXT NOT NULL DEFAULT '',cost_center TEXT NOT NULL DEFAULT ''," +
                "has_attachment INTEGER NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_cashbox_transactions(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "receipt_no TEXT NOT NULL DEFAULT '',transaction_date TEXT NOT NULL DEFAULT ''," +
                "transaction_type TEXT NOT NULL DEFAULT '',method TEXT NOT NULL DEFAULT ''," +
                "amount REAL NOT NULL DEFAULT 0,party TEXT NOT NULL DEFAULT ''," +
                "reference_no TEXT NOT NULL DEFAULT '',cashier_code TEXT NOT NULL DEFAULT ''," +
                "has_attachment INTEGER NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_direct_payments(" +
                "namespace TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "receipt_no TEXT NOT NULL DEFAULT '',subscriber_id TEXT NOT NULL DEFAULT ''," +
                "subscriber_code TEXT NOT NULL DEFAULT '',meter_no TEXT NOT NULL DEFAULT ''," +
                "payment_date TEXT NOT NULL DEFAULT '',amount REAL NOT NULL DEFAULT 0," +
                "income_type TEXT NOT NULL DEFAULT '',method TEXT NOT NULL DEFAULT ''," +
                "cashier_code TEXT NOT NULL DEFAULT '',has_attachment INTEGER NOT NULL DEFAULT 0," +
                commonProjectionColumns() + ",PRIMARY KEY(namespace,entity_id))");

        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_entity_versions(" +
                "namespace TEXT NOT NULL,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "entity_version INTEGER NOT NULL,payload_hash TEXT NOT NULL," +
                "is_deleted INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL," +
                "PRIMARY KEY(namespace,entity_type,entity_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS qatra_sync_outbox(" +
                "local_sequence INTEGER PRIMARY KEY AUTOINCREMENT," +
                "operation_id TEXT NOT NULL UNIQUE,namespace TEXT NOT NULL," +
                "entity_type TEXT NOT NULL,entity_id TEXT NOT NULL," +
                "action TEXT NOT NULL CHECK(action IN('UPSERT','DELETE'))," +
                "payload_json TEXT NOT NULL,payload_hash TEXT NOT NULL," +
                "entity_version INTEGER NOT NULL,source TEXT NOT NULL," +
                "status TEXT NOT NULL DEFAULT 'PENDING' " +
                "CHECK(status IN('PENDING','FAILED','ACKNOWLEDGED'))," +
                "created_at INTEGER NOT NULL,acknowledged_at INTEGER," +
                "last_error TEXT NOT NULL DEFAULT ''," +
                "UNIQUE(namespace,entity_type,entity_id,entity_version,action))");

        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_subscriber_code " +
                "ON qatra_subscribers(namespace,subscriber_code)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_meter_no " +
                "ON qatra_subscribers(namespace,meter_no)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_cycles_date " +
                "ON qatra_billing_cycles(namespace,cycle_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_readings_relation " +
                "ON qatra_meter_readings(namespace,cycle_id,subscriber_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_invoices_relation " +
                "ON qatra_invoices(namespace,subscriber_id,invoice_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_payments_relation " +
                "ON qatra_payments(namespace,subscriber_id,payment_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_expenses_date " +
                "ON qatra_expenses(namespace,expense_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_cashbox_date " +
                "ON qatra_cashbox_transactions(namespace,transaction_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS ix_qatra_outbox_pending " +
                "ON qatra_sync_outbox(status,local_sequence)");
    }

    private static void createBusinessRuleSchema(SQLiteDatabase db) {
        createUniqueIndex(db, "uq_qatra_subscriber_code",
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_qatra_subscriber_code " +
                        "ON qatra_subscribers(namespace,subscriber_code COLLATE NOCASE) " +
                        "WHERE subscriber_code<>''");
        createUniqueIndex(db, "uq_qatra_meter_no",
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_qatra_meter_no " +
                        "ON qatra_subscribers(namespace,meter_no COLLATE NOCASE) " +
                        "WHERE meter_no<>''");
        createUniqueIndex(db, "uq_qatra_cycle_type_date",
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_qatra_cycle_type_date " +
                        "ON qatra_billing_cycles(namespace,cycle_type,cycle_date) " +
                        "WHERE cycle_type<>'' AND cycle_date<>''");
        createUniqueIndex(db, "uq_qatra_reading_cycle_subscriber",
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_qatra_reading_cycle_subscriber " +
                        "ON qatra_meter_readings(namespace,cycle_id,subscriber_id) " +
                        "WHERE cycle_id<>'' AND subscriber_id<>''");

        db.execSQL("CREATE TRIGGER IF NOT EXISTS trg_qatra_subscriber_numbers_insert " +
                "BEFORE INSERT ON qatra_subscribers BEGIN " +
                "SELECT CASE WHEN NEW.opening_reading<0 OR NEW.opening_arrears<0 " +
                "OR NEW.opening_credit<0 THEN RAISE(ABORT,'NEGATIVE_SUBSCRIBER_VALUE') END; " +
                "SELECT CASE WHEN NEW.opening_arrears>0 AND NEW.opening_credit>0 " +
                "THEN RAISE(ABORT,'ARREARS_AND_CREDIT_CONFLICT') END; END");
        db.execSQL("CREATE TRIGGER IF NOT EXISTS trg_qatra_subscriber_numbers_update " +
                "BEFORE UPDATE OF opening_reading,opening_arrears,opening_credit ON qatra_subscribers BEGIN " +
                "SELECT CASE WHEN NEW.opening_reading<0 OR NEW.opening_arrears<0 " +
                "OR NEW.opening_credit<0 THEN RAISE(ABORT,'NEGATIVE_SUBSCRIBER_VALUE') END; " +
                "SELECT CASE WHEN NEW.opening_arrears>0 AND NEW.opening_credit>0 " +
                "THEN RAISE(ABORT,'ARREARS_AND_CREDIT_CONFLICT') END; END");
        db.execSQL("CREATE TRIGGER IF NOT EXISTS trg_qatra_reading_numbers_insert " +
                "BEFORE INSERT ON qatra_meter_readings BEGIN " +
                "SELECT CASE WHEN NEW.previous_reading<0 OR NEW.current_reading<0 " +
                "OR NEW.consumption<0 THEN RAISE(ABORT,'NEGATIVE_READING_VALUE') END; " +
                "SELECT CASE WHEN NEW.meter_changed=0 AND NEW.current_reading<NEW.previous_reading " +
                "THEN RAISE(ABORT,'CURRENT_READING_BELOW_PREVIOUS') END; END");
        db.execSQL("CREATE TRIGGER IF NOT EXISTS trg_qatra_reading_numbers_update " +
                "BEFORE UPDATE OF previous_reading,current_reading,consumption,meter_changed " +
                "ON qatra_meter_readings BEGIN " +
                "SELECT CASE WHEN NEW.previous_reading<0 OR NEW.current_reading<0 " +
                "OR NEW.consumption<0 THEN RAISE(ABORT,'NEGATIVE_READING_VALUE') END; " +
                "SELECT CASE WHEN NEW.meter_changed=0 AND NEW.current_reading<NEW.previous_reading " +
                "THEN RAISE(ABORT,'CURRENT_READING_BELOW_PREVIOUS') END; END");
    }

    private static void ensureColumn(
            SQLiteDatabase db, String table, String column, String definition) {
        try (Cursor c = db.rawQuery("PRAGMA table_info(" + table + ")", null)) {
            int nameIndex = c.getColumnIndex("name");
            while (c.moveToNext()) {
                if (column.equals(c.getString(nameIndex))) return;
            }
        }
        db.execSQL("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
    }

    private static void createUniqueIndex(SQLiteDatabase db, String name, String sql) {
        try {
            db.execSQL(sql);
        } catch (android.database.sqlite.SQLiteConstraintException conflict) {
            // Keep legacy installations readable. New state saves still fail closed through
            // validateBusinessRules until the operator corrects the conflicting legacy row.
            audit(db, "LEGACY_UNIQUE_CONFLICT", name);
        }
    }

    private static String commonProjectionColumns() {
        return "source_updated_at TEXT NOT NULL DEFAULT '',payload_json TEXT NOT NULL," +
                "payload_hash TEXT NOT NULL,updated_at INTEGER NOT NULL,sync_version INTEGER NOT NULL";
    }

    private static void backfillRelationalState(SQLiteDatabase db) throws Exception {
        try (Cursor c = db.rawQuery("SELECT namespace,payload_json,updated_at FROM app_state", null)) {
            while (c.moveToNext()) {
                projectRelationalState(db, c.getString(0), new JSONObject(c.getString(1)),
                        "SCHEMA_MIGRATION", c.getLong(2));
            }
        }
    }

    private static void projectRelationalState(
            SQLiteDatabase db, String namespace, JSONObject root, String source, long now) throws Exception {
        LinkedHashMap<String, JSONObject> profiles = new LinkedHashMap<>();
        JSONObject meta = root.optJSONObject("meta");
        JSONObject settings = root.optJSONObject("settings");
        if (meta != null || settings != null) {
            JSONObject profile = new JSONObject();
            profile.put("id", "PROFILE");
            if (meta != null) profile.put("meta", meta);
            if (settings != null) profile.put("settings", settings);
            profiles.put("PROFILE", profile);
        }
        syncProjectionTable(db, "qatra_profiles", "BUSINESS_PROFILE", namespace, profiles, source, now);

        LinkedHashMap<String, JSONObject> staff = new LinkedHashMap<>();
        collectRows(root.optJSONArray("users"), staff, "STAFF_USER", "id", "username", "code");
        syncProjectionTable(db, "qatra_staff_users", "STAFF_USER", namespace, staff, source, now);

        LinkedHashMap<String, JSONObject> subscribers = new LinkedHashMap<>();
        collectRows(root.optJSONArray("subscribers"), subscribers, "SUBSCRIBER",
                "id", "subscriberId", "code", "subscriberCode", "meterNo");
        JSONObject assignment = root.optJSONObject("assignment");
        if (assignment != null) collectRows(assignment.optJSONArray("subscribers"), subscribers,
                "SUBSCRIBER", "id", "subscriberId", "code", "subscriberCode", "meterNo");
        JSONObject setup = root.optJSONObject("setup");
        if (setup != null) collectRows(setup.optJSONArray("subscribers"), subscribers,
                "SUBSCRIBER", "id", "subscriberId", "code", "subscriberCode", "meterNo");
        syncProjectionTable(db, "qatra_subscribers", "SUBSCRIBER", namespace, subscribers, source, now);

        LinkedHashMap<String, JSONObject> cycles = new LinkedHashMap<>();
        collectRows(root.optJSONArray("cycles"), cycles, "BILLING_CYCLE", "id");
        if (assignment != null) collectObject(assignment.optJSONObject("cycle"), cycles,
                "BILLING_CYCLE", "id");
        syncProjectionTable(db, "qatra_billing_cycles", "BILLING_CYCLE", namespace, cycles, source, now);

        LinkedHashMap<String, JSONObject> readings = new LinkedHashMap<>();
        collectRows(root.optJSONArray("readings"), readings, "METER_READING", "id");
        syncProjectionTable(db, "qatra_meter_readings", "METER_READING", namespace, readings, source, now);

        LinkedHashMap<String, JSONObject> invoices = new LinkedHashMap<>();
        collectRows(root.optJSONArray("invoices"), invoices, "INVOICE", "id", "no");
        syncProjectionTable(db, "qatra_invoices", "INVOICE", namespace, invoices, source, now);

        LinkedHashMap<String, JSONObject> payments = new LinkedHashMap<>();
        collectRows(root.optJSONArray("payments"), payments, "PAYMENT", "id", "receiptNo");
        collectRows(root.optJSONArray("receipts"), payments, "PAYMENT", "id", "receiptNo");
        syncProjectionTable(db, "qatra_payments", "PAYMENT", namespace, payments, source, now);

        LinkedHashMap<String, JSONObject> expenses = new LinkedHashMap<>();
        collectRows(root.optJSONArray("expenses"), expenses, "EXPENSE", "id", "refNo");
        syncProjectionTable(db, "qatra_expenses", "EXPENSE", namespace, expenses, source, now);

        LinkedHashMap<String, JSONObject> cashbox = new LinkedHashMap<>();
        collectRows(root.optJSONArray("transactions"), cashbox, "CASHBOX_TRANSACTION", "id", "receiptNo");
        collectRows(root.optJSONArray("cashboxTransactions"), cashbox,
                "CASHBOX_TRANSACTION", "id", "receiptNo");
        syncProjectionTable(db, "qatra_cashbox_transactions", "CASHBOX_TRANSACTION",
                namespace, cashbox, source, now);

        LinkedHashMap<String, JSONObject> direct = new LinkedHashMap<>();
        collectRows(root.optJSONArray("directPayments"), direct, "DIRECT_PAYMENT", "id", "receiptNo");
        collectRows(root.optJSONArray("cashboxDirectPayments"), direct,
                "DIRECT_PAYMENT", "id", "receiptNo");
        syncProjectionTable(db, "qatra_direct_payments", "DIRECT_PAYMENT", namespace, direct, source, now);
    }

    private static void collectRows(
            JSONArray array, Map<String, JSONObject> target, String entityType, String... idKeys) throws Exception {
        if (array == null) return;
        for (int i = 0; i < array.length(); i++) {
            JSONObject row = array.optJSONObject(i);
            if (row == null) continue;
            String id = stableEntityId(row, entityType, idKeys);
            target.put(id, row);
        }
    }

    private static void collectObject(
            JSONObject row, Map<String, JSONObject> target, String entityType, String... idKeys) throws Exception {
        if (row == null) return;
        target.put(stableEntityId(row, entityType, idKeys), row);
    }

    private static String stableEntityId(JSONObject row, String type, String... keys) throws Exception {
        for (String key : keys) {
            String value = row.optString(key, "").trim();
            if (!value.isEmpty()) return value;
        }
        JSONObject safePayload = sanitizedPayload(row);
        return type + "-" + sha256(safePayload.toString()).substring(0, 20);
    }

    private static void syncProjectionTable(
            SQLiteDatabase db, String table, String entityType, String namespace,
            Map<String, JSONObject> incoming, String source, long now) throws Exception {
        Set<String> seen = new HashSet<>();
        for (Map.Entry<String, JSONObject> entry : incoming.entrySet()) {
            String entityId = entry.getKey();
            JSONObject payload = sanitizedPayload(entry.getValue());
            ContentValues values = projectionValues(entityType, entry.getValue());
            upsertProjectedRow(db, table, entityType, namespace, entityId,
                    payload, values, source, now);
            seen.add(entityId);
        }
        Set<String> missing = new HashSet<>();
        try (Cursor c = db.query(table, new String[]{"entity_id"}, "namespace=?",
                new String[]{namespace}, null, null, null)) {
            while (c.moveToNext()) {
                String entityId = c.getString(0);
                if (!seen.contains(entityId)) missing.add(entityId);
            }
        }
        for (String entityId : missing) {
            db.delete(table, "namespace=? AND entity_id=?", new String[]{namespace, entityId});
            recordDeletion(db, namespace, entityType, entityId, source, now);
        }
    }

    private static void upsertProjectedRow(
            SQLiteDatabase db, String table, String entityType, String namespace, String entityId,
            JSONObject payload, ContentValues values, String source, long now) throws Exception {
        String payloadJson = payload.toString();
        String payloadHash = sha256(payloadJson);
        VersionState current = versionState(db, namespace, entityType, entityId);
        if (current != null && !current.deleted && payloadHash.equals(current.payloadHash)) {
            if (!projectionRowExists(db, table, namespace, entityId)) {
                values.put("namespace", namespace);
                values.put("entity_id", entityId);
                values.put("payload_json", payloadJson);
                values.put("payload_hash", payloadHash);
                values.put("updated_at", now);
                values.put("sync_version", current.version);
                if (db.insertWithOnConflict(
                        table, null, values, SQLiteDatabase.CONFLICT_REPLACE) == -1L) {
                    throw new IllegalStateException("تعذر استعادة جدول " + table);
                }
            }
            return;
        }

        long version = current == null ? 1L : current.version + 1L;
        values.put("namespace", namespace);
        values.put("entity_id", entityId);
        values.put("payload_json", payloadJson);
        values.put("payload_hash", payloadHash);
        values.put("updated_at", now);
        values.put("sync_version", version);
        long inserted = db.insertWithOnConflict(table, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        if (inserted == -1L) throw new IllegalStateException("تعذر تحديث جدول " + table);

        saveVersionState(db, namespace, entityType, entityId, version, payloadHash, false, now);
        enqueueEntityChange(db, namespace, entityType, entityId, "UPSERT",
                payloadJson, payloadHash, version, source, now);
    }

    private static void recordDeletion(
            SQLiteDatabase db, String namespace, String entityType, String entityId,
            String source, long now) throws Exception {
        VersionState current = versionState(db, namespace, entityType, entityId);
        if (current != null && current.deleted) return;
        long version = current == null ? 1L : current.version + 1L;
        JSONObject tombstone = new JSONObject();
        tombstone.put("id", entityId);
        tombstone.put("deleted", true);
        String payloadJson = tombstone.toString();
        String payloadHash = sha256(payloadJson);
        saveVersionState(db, namespace, entityType, entityId, version, payloadHash, true, now);
        enqueueEntityChange(db, namespace, entityType, entityId, "DELETE",
                payloadJson, payloadHash, version, source, now);
    }

    private static void enqueueEntityChange(
            SQLiteDatabase db, String namespace, String entityType, String entityId,
            String action, String payloadJson, String payloadHash, long version,
            String source, long now) {
        // Only the newest unacknowledged state of an entity is needed. This bounds database
        // growth before the accounting connector is enabled and remains safe because the server
        // accepts the highest entity_version and treats operation_id as idempotent.
        db.delete("qatra_sync_outbox",
                "namespace=? AND entity_type=? AND entity_id=? AND status IN('PENDING','FAILED')",
                new String[]{namespace, entityType, entityId});
        ContentValues change = new ContentValues();
        change.put("operation_id", UUID.randomUUID().toString());
        change.put("namespace", namespace);
        change.put("entity_type", entityType);
        change.put("entity_id", entityId);
        change.put("action", action);
        change.put("payload_json", payloadJson);
        change.put("payload_hash", payloadHash);
        change.put("entity_version", version);
        change.put("source", source == null ? "LOCAL" : source);
        change.put("status", "PENDING");
        change.put("created_at", now);
        long inserted = db.insertWithOnConflict(
                "qatra_sync_outbox", null, change, SQLiteDatabase.CONFLICT_IGNORE);
        if (inserted == -1L && !outboxVersionExists(
                db, namespace, entityType, entityId, version, action)) {
            throw new IllegalStateException("تعذر إنشاء حركة مزامنة محاسبية");
        }
    }

    private static boolean outboxVersionExists(
            SQLiteDatabase db, String namespace, String entityType,
            String entityId, long version, String action) {
        try (Cursor c = db.rawQuery(
                "SELECT 1 FROM qatra_sync_outbox WHERE namespace=? AND entity_type=? " +
                        "AND entity_id=? AND entity_version=? AND action=? LIMIT 1",
                new String[]{namespace, entityType, entityId, String.valueOf(version), action})) {
            return c.moveToFirst();
        }
    }

    private static boolean projectionRowExists(
            SQLiteDatabase db, String table, String namespace, String entityId) {
        try (Cursor c = db.query(table, new String[]{"entity_id"},
                "namespace=? AND entity_id=?", new String[]{namespace, entityId},
                null, null, null, "1")) {
            return c.moveToFirst();
        }
    }

    private static VersionState versionState(
            SQLiteDatabase db, String namespace, String entityType, String entityId) {
        try (Cursor c = db.rawQuery(
                "SELECT entity_version,payload_hash,is_deleted FROM qatra_entity_versions " +
                        "WHERE namespace=? AND entity_type=? AND entity_id=? LIMIT 1",
                new String[]{namespace, entityType, entityId})) {
            return c.moveToFirst()
                    ? new VersionState(c.getLong(0), c.getString(1), c.getInt(2) != 0) : null;
        }
    }

    private static void saveVersionState(
            SQLiteDatabase db, String namespace, String entityType, String entityId,
            long version, String payloadHash, boolean deleted, long now) {
        ContentValues values = new ContentValues();
        values.put("namespace", namespace);
        values.put("entity_type", entityType);
        values.put("entity_id", entityId);
        values.put("entity_version", version);
        values.put("payload_hash", payloadHash);
        values.put("is_deleted", deleted ? 1 : 0);
        values.put("updated_at", now);
        db.insertWithOnConflict(
                "qatra_entity_versions", null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    private static ContentValues projectionValues(String type, JSONObject row) {
        ContentValues values = new ContentValues();
        values.put("source_updated_at", firstString(row, "updatedAt", "createdAt", "date", "cycleDate"));
        if ("BUSINESS_PROFILE".equals(type)) {
            JSONObject settings = row.optJSONObject("settings");
            if (settings == null) settings = new JSONObject();
            values.put("project_name", settings.optString("projectName", ""));
            values.put("owner_name", settings.optString("ownerName", ""));
            values.put("account_no", settings.optString("projectAccountNo", ""));
            values.put("currency", firstString(settings, "currency", "currencyFull", "currencyShort"));
        } else if ("STAFF_USER".equals(type)) {
            values.put("username", row.optString("username", ""));
            values.put("display_name", row.optString("name", ""));
            values.put("role", row.optString("role", ""));
            values.put("employee_code", row.optString("code", ""));
            values.put("active", row.optBoolean("active", true) ? 1 : 0);
        } else if ("SUBSCRIBER".equals(type)) {
            values.put("subscriber_code", firstString(row, "code", "subscriberCode"));
            values.put("meter_no", row.optString("meterNo", ""));
            values.put("full_name", firstString(row, "name", "subscriberName"));
            values.put("phone", row.optString("phone", ""));
            values.put("area", row.optString("area", ""));
            values.put("status", row.optString("status", ""));
            values.put("reading_group", row.optString("readingGroup", ""));
            values.put("opening_reading", finiteNumber(row, "openingReading"));
            values.put("opening_arrears", finiteNumber(row, "openingArrears"));
            values.put("opening_credit", finiteNumber(row, "openingCredit"));
        } else if ("BILLING_CYCLE".equals(type)) {
            values.put("cycle_date", row.optString("cycleDate", ""));
            values.put("cycle_type", row.optString("type", ""));
            values.put("status", row.optString("status", ""));
            values.put("main_previous", finiteNumber(row, "mainPrev"));
            values.put("main_current", finiteNumber(row, "mainCurrent"));
            values.put("closed_at", row.optString("closedAt", ""));
        } else if ("METER_READING".equals(type)) {
            values.put("cycle_id", row.optString("cycleId", ""));
            values.put("subscriber_id", row.optString("subscriberId", ""));
            values.put("previous_reading", finiteNumber(row, "prev", "previousReading"));
            values.put("current_reading", finiteNumber(row, "current", "currentReading"));
            values.put("consumption", finiteNumber(row, "consumption"));
            values.put("reader_id", row.optString("readerId", ""));
            values.put("assignment_id", row.optString("assignmentId", ""));
            values.put("meter_changed", row.optString("meterChangeId", "").trim().isEmpty() ? 0 : 1);
            values.put("has_attachment", hasBinaryAttachment(row) ? 1 : 0);
        } else if ("INVOICE".equals(type)) {
            values.put("invoice_no", row.optString("no", ""));
            values.put("cycle_id", row.optString("cycleId", ""));
            values.put("subscriber_id", row.optString("subscriberId", ""));
            values.put("invoice_date", row.optString("date", ""));
            values.put("amount", finiteNumber(row, "amount"));
            values.put("paid_amount", finiteNumber(row, "paidAmount"));
            values.put("remaining_amount", finiteNumber(row, "remainingAmount"));
            values.put("status", row.optString("status", ""));
        } else if ("PAYMENT".equals(type)) {
            values.put("receipt_no", row.optString("receiptNo", ""));
            values.put("subscriber_id", row.optString("subscriberId", ""));
            values.put("invoice_id", row.optString("invoiceId", ""));
            values.put("payment_date", row.optString("date", ""));
            values.put("amount", finiteNumber(row, "amount"));
            values.put("method", row.optString("method", ""));
            values.put("collector_id", firstString(row, "collectorId", "collectorCode", "collector"));
            values.put("income_type", row.optString("incomeType", "WATER"));
            values.put("confirmed", row.optBoolean("confirmed", true) ? 1 : 0);
            values.put("has_attachment", hasBinaryAttachment(row) ? 1 : 0);
        } else if ("EXPENSE".equals(type)) {
            values.put("expense_date", row.optString("date", ""));
            values.put("category", row.optString("category", ""));
            values.put("description", row.optString("description", ""));
            values.put("amount", finiteNumber(row, "amount"));
            values.put("payee", row.optString("payee", ""));
            values.put("reference_no", row.optString("refNo", ""));
            values.put("payment_account", row.optString("paymentAccount", ""));
            values.put("cost_center", row.optString("costCenter", ""));
            values.put("has_attachment", hasBinaryAttachment(row) ? 1 : 0);
        } else if ("CASHBOX_TRANSACTION".equals(type)) {
            values.put("receipt_no", row.optString("receiptNo", ""));
            values.put("transaction_date", row.optString("date", ""));
            values.put("transaction_type", row.optString("type", ""));
            values.put("method", row.optString("method", ""));
            values.put("amount", finiteNumber(row, "amount"));
            values.put("party", row.optString("party", ""));
            values.put("reference_no", firstString(row, "refNo", "referenceNo"));
            values.put("cashier_code", row.optString("cashierCode", ""));
            values.put("has_attachment", hasBinaryAttachment(row) ? 1 : 0);
        } else if ("DIRECT_PAYMENT".equals(type)) {
            values.put("receipt_no", row.optString("receiptNo", ""));
            values.put("subscriber_id", row.optString("subscriberId", ""));
            values.put("subscriber_code", row.optString("subscriberCode", ""));
            values.put("meter_no", row.optString("meterNo", ""));
            values.put("payment_date", row.optString("date", ""));
            values.put("amount", finiteNumber(row, "amount"));
            values.put("income_type", row.optString("incomeType", "WATER"));
            values.put("method", row.optString("method", ""));
            values.put("cashier_code", row.optString("cashierCode", ""));
            values.put("has_attachment", hasBinaryAttachment(row) ? 1 : 0);
        }
        return values;
    }

    private static JSONObject sanitizedPayload(JSONObject source) throws Exception {
        Object cleaned = sanitizeJson(source);
        return cleaned instanceof JSONObject ? (JSONObject) cleaned : new JSONObject();
    }

    private static Object sanitizeJson(Object value) throws Exception {
        if (value == null || value == JSONObject.NULL) return JSONObject.NULL;
        if (value instanceof JSONObject) {
            JSONObject source = (JSONObject) value;
            JSONObject result = new JSONObject();
            JSONArray names = source.names();
            if (names == null) return result;
            for (int i = 0; i < names.length(); i++) {
                String key = names.optString(i, "");
                Object child = source.opt(key);
                if (isBinaryKey(key)) {
                    if (child != null && child != JSONObject.NULL && !String.valueOf(child).isEmpty()) {
                        result.put(key + "Present", true);
                    }
                } else {
                    result.put(key, sanitizeJson(child));
                }
            }
            return result;
        }
        if (value instanceof JSONArray) {
            JSONArray source = (JSONArray) value;
            JSONArray result = new JSONArray();
            for (int i = 0; i < source.length(); i++) result.put(sanitizeJson(source.opt(i)));
            return result;
        }
        return value;
    }

    private static boolean isBinaryKey(String key) {
        String normalized = key == null ? "" : key.toLowerCase(Locale.ROOT);
        return normalized.endsWith("photo") || "projectlogo".equals(normalized);
    }

    private static boolean hasBinaryAttachment(JSONObject row) {
        for (String key : new String[]{"photo", "receiptPhoto", "attachmentPhoto"}) {
            if (!row.optString(key, "").isEmpty()) return true;
        }
        return false;
    }

    private static String firstString(JSONObject row, String... keys) {
        if (row == null) return "";
        for (String key : keys) {
            String value = row.optString(key, "").trim();
            if (!value.isEmpty()) return value;
        }
        return "";
    }

    private static double finiteNumber(JSONObject row, String... keys) {
        if (row == null) return 0d;
        for (String key : keys) {
            Object value = row.opt(key);
            if (value == null || value == JSONObject.NULL || String.valueOf(value).trim().isEmpty()) continue;
            try {
                double number = Double.parseDouble(String.valueOf(value).replace(",", ""));
                return Double.isNaN(number) || Double.isInfinite(number) ? 0d : number;
            } catch (NumberFormatException ignored) { }
        }
        return 0d;
    }

    private static final class VersionState {
        final long version;
        final String payloadHash;
        final boolean deleted;

        VersionState(long version, String payloadHash, boolean deleted) {
            this.version = version;
            this.payloadHash = payloadHash == null ? "" : payloadHash;
            this.deleted = deleted;
        }
    }

    private static String chooseId(JSONObject row, String type, int index) throws Exception {
        for (String key : new String[]{"id", "packageId", "operationId", "receiptNo", "no", "code"}) {
            String value = row.optString(key, "").trim();
            if (!value.isEmpty()) return value;
        }
        return type.toUpperCase(Locale.ROOT) + "-" + index + "-" + sha256(row.toString()).substring(0, 16);
    }

    private static ContentValues syncValues(
            String packageId, String operationId, String direction, String senderRole,
            String targetRole, String operationType, String payloadHash, String status) {
        ContentValues values = new ContentValues();
        values.put("package_id", packageId);
        values.put("operation_id", operationId);
        values.put("direction", direction);
        values.put("sender_role", senderRole);
        values.put("target_role", targetRole);
        values.put("operation_type", operationType);
        values.put("payload_hash", payloadHash);
        values.put("status", status);
        values.put("created_at", System.currentTimeMillis());
        return values;
    }

    private static boolean hasState(SQLiteDatabase db, String namespace) {
        try (Cursor c = db.rawQuery("SELECT 1 FROM app_state WHERE namespace=? LIMIT 1", new String[]{namespace})) {
            return c.moveToFirst();
        }
    }

    private static String primaryNamespaceForRole(String role) {
        if ("ADMIN".equals(role)) return "admin";
        if ("READER".equals(role)) return "reader";
        if ("COLLECTOR".equals(role)) return "collector";
        if ("CASHIER".equals(role)) return "cashier";
        throw new SecurityException("صلاحية النسخة الاحتياطية غير معروفة");
    }

    private static java.util.List<String> portableNamespacesForRole(String role) {
        if ("ADMIN".equals(role)) return Arrays.asList(
                "admin", "admin.staff", "admin.reader.config",
                "admin.collector.config", "admin.cashbox");
        return Collections.singletonList(primaryNamespaceForRole(role));
    }

    private static JSONObject preserveOperationalStart(
            SQLiteDatabase db, String namespace, JSONObject incoming) throws Exception {
        JSONObject restored = new JSONObject(incoming.toString());
        String currentJson = stateInTransaction(db, namespace);
        if (currentJson == null) return restored;
        JSONObject current = new JSONObject(currentJson);
        if ("admin".equals(namespace)) {
            JSONObject oldMeta = current.optJSONObject("meta");
            String started = oldMeta == null ? "" : oldMeta.optString("productionStartedAt", "");
            JSONObject newMeta = restored.optJSONObject("meta");
            if (newMeta == null) { newMeta = new JSONObject(); restored.put("meta", newMeta); }
            if (!started.isEmpty() && newMeta.optString("productionStartedAt", "").isEmpty()) {
                newMeta.put("productionStartedAt", started);
            }
        } else {
            String started = current.optString("operationalStartedAt", "");
            if (!started.isEmpty() && restored.optString("operationalStartedAt", "").isEmpty()) {
                restored.put("operationalStartedAt", started);
            }
        }
        return restored;
    }

    private static String stateInTransaction(SQLiteDatabase db, String namespace) {
        try (Cursor c = db.query("app_state", new String[]{"payload_json"}, "namespace=?",
                new String[]{namespace}, null, null, null, "1")) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    private static boolean hasMigration(SQLiteDatabase db, String namespace) {
        try (Cursor c = db.rawQuery("SELECT 1 FROM migration_log WHERE namespace=? LIMIT 1", new String[]{namespace})) {
            return c.moveToFirst();
        }
    }

    private static boolean isProcessedInTransaction(SQLiteDatabase db, String packageId, String operationId) {
        try (Cursor c = db.rawQuery(
                "SELECT 1 FROM sync_packages WHERE (package_id=? OR operation_id=?) AND status='PROCESSED' LIMIT 1",
                new String[]{safe(packageId), safe(operationId)})) {
            return c.moveToFirst();
        }
    }

    private static long count(SQLiteDatabase db, String table) {
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM " + table, null)) {
            return c.moveToFirst() ? c.getLong(0) : 0L;
        }
    }

    private static long countWhere(SQLiteDatabase db, String table, String where) {
        try (Cursor c = db.rawQuery(
                "SELECT COUNT(*) FROM " + table + " WHERE " + where, null)) {
            return c.moveToFirst() ? c.getLong(0) : 0L;
        }
    }

    private static void audit(SQLiteDatabase db, String eventType, String details) {
        ContentValues row = new ContentValues();
        row.put("event_type", eventType);
        row.put("details", details == null ? "" : details);
        row.put("created_at", System.currentTimeMillis());
        db.insert("audit_log", null, row);
        db.execSQL("DELETE FROM audit_log WHERE id NOT IN " +
                "(SELECT id FROM audit_log ORDER BY id DESC LIMIT 5000)");
    }

    private static void validateNamespace(String namespace) {
        if (namespace == null || !namespace.matches("[a-z0-9_.-]{1,80}")) {
            throw new IllegalArgumentException("نطاق التخزين غير صالح");
        }
    }

    private static void validateState(String namespace, String payloadJson) throws Exception {
        validateNamespace(namespace);
        if (payloadJson == null || payloadJson.length() > 20_000_000) {
            throw new IllegalArgumentException("حجم البيانات غير صالح");
        }
        validateBusinessRules(new JSONObject(payloadJson));
    }

    private static void validateBusinessRules(JSONObject root) {
        JSONArray subscribers = root.optJSONArray("subscribers");
        Set<String> subscriberCodes = new HashSet<>();
        Set<String> meterNumbers = new HashSet<>();
        if (subscribers != null) {
            for (int i = 0; i < subscribers.length(); i++) {
                JSONObject row = subscribers.optJSONObject(i);
                if (row == null) continue;
                String code = normalizedBusinessKey(firstString(row, "code", "subscriberCode"));
                String meter = normalizedBusinessKey(row.optString("meterNo", ""));
                if (!code.isEmpty() && !subscriberCodes.add(code)) {
                    throw new IllegalArgumentException("رقم المشترك مكرر");
                }
                if (!meter.isEmpty() && !meterNumbers.add(meter)) {
                    throw new IllegalArgumentException("رقم العداد مكرر");
                }
                double opening = strictNonNegativeNumber(row, "openingReading", "القراءة الافتتاحية");
                double arrears = strictNonNegativeNumber(row, "openingArrears", "المتأخرات السابقة");
                double credit = strictNonNegativeNumber(row, "openingCredit", "الرصيد المقدم");
                if (opening < 0 || arrears < 0 || credit < 0) {
                    throw new IllegalArgumentException("قيم المشترك الرقمية لا يمكن أن تكون سالبة");
                }
                if (arrears > 0 && credit > 0) {
                    throw new IllegalArgumentException(
                            "لا يمكن الجمع بين المتأخرات السابقة والرصيد المقدم");
                }
            }
        }

        JSONArray cycles = root.optJSONArray("cycles");
        Set<String> cycleKeys = new HashSet<>();
        if (cycles != null) {
            for (int i = 0; i < cycles.length(); i++) {
                JSONObject row = cycles.optJSONObject(i);
                if (row == null) continue;
                String date = row.optString("cycleDate", "").trim();
                String type = normalizedBusinessKey(row.optString("type", ""));
                if (!date.isEmpty() && !date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                    throw new IllegalArgumentException("تاريخ دورة القراءة غير صالح");
                }
                if (!date.isEmpty() && !type.isEmpty() && !cycleKeys.add(type + "|" + date)) {
                    throw new IllegalArgumentException("توجد دورة قراءة مكررة في التاريخ نفسه");
                }
                Object mainCurrent = row.opt("mainCurrent");
                if (mainCurrent != null && mainCurrent != JSONObject.NULL
                        && !String.valueOf(mainCurrent).trim().isEmpty()) {
                    double previous = strictNonNegativeNumber(row, "mainPrev", "القراءة الرئيسية السابقة");
                    double current = strictNonNegativeNumber(row, "mainCurrent", "القراءة الرئيسية الحالية");
                    if (current < previous) {
                        throw new IllegalArgumentException(
                                "القراءة الرئيسية الحالية لا يمكن أن تقل عن السابقة");
                    }
                }
            }
        }

        JSONArray readings = root.optJSONArray("readings");
        Set<String> readingKeys = new HashSet<>();
        if (readings != null) {
            for (int i = 0; i < readings.length(); i++) {
                JSONObject row = readings.optJSONObject(i);
                if (row == null) continue;
                String cycleId = row.optString("cycleId", "").trim();
                String subscriberId = row.optString("subscriberId", "").trim();
                String relation = cycleId + "|" + subscriberId;
                if (!cycleId.isEmpty() && !subscriberId.isEmpty() && !readingKeys.add(relation)) {
                    throw new IllegalArgumentException("توجد قراءة مكررة للمشترك في الدورة نفسها");
                }
                double previous = strictNonNegativeNumber(row, "prev", "القراءة السابقة");
                double current = strictNonNegativeNumber(row, "current", "القراءة الحالية");
                strictNonNegativeNumber(row, "consumption", "الاستهلاك");
                boolean meterChanged = !row.optString("meterChangeId", "").trim().isEmpty();
                if (!meterChanged && current < previous) {
                    throw new IllegalArgumentException(
                            "القراءة الحالية لا يمكن أن تقل عن القراءة السابقة");
                }
            }
        }
    }

    private static double strictNonNegativeNumber(JSONObject row, String key, String label) {
        Object raw = row.opt(key);
        if (raw == null || raw == JSONObject.NULL || String.valueOf(raw).trim().isEmpty()) return 0d;
        try {
            double value = Double.parseDouble(String.valueOf(raw).replace(",", "").trim());
            if (Double.isNaN(value) || Double.isInfinite(value) || value < 0d) {
                throw new NumberFormatException();
            }
            return value;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(label + " يجب أن تكون رقمًا موجبًا أو صفرًا");
        }
    }

    private static String normalizedBusinessKey(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private static String safe(String value) { return value == null ? "" : value; }

    public static String sha256(String text) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder(hash.length * 2);
        for (byte b : hash) out.append(String.format(Locale.US, "%02x", b & 0xff));
        return out.toString();
    }
}
