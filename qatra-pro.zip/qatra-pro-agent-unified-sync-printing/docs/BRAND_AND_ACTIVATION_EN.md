# Qatra Pro 2.7.1 — Brand and Activation

## Brand system

- Product name: **QATRA PRO**
- Descriptor: **WATER UTILITY MANAGEMENT SYSTEM**
- Tagline: **EVERY DROP ACCOUNTED FOR**
- Core palette: deep navy `#102A43`, classic gold `#B08D57`, utility blue `#1E73BE`, aqua `#2CC4C7`, and warm cream `#F6F1E7`.
- The same classic droplet mark is used for the launcher and round launcher icons.
- English role labels are used for Administration, Field Reader, Collector, and Cashier APKs.

## Commercial activation

Every role application uses the same native commercial-license boundary:

1. A protected 30-day free trial is created on first use.
2. The customer copies the device-bound activation request.
3. The customer purchases activation through WhatsApp/call at `774777164` or email at `abdulazizgh033@gmail.com`.
4. The owner generates a signed permanent activation file or token outside the APK.
5. The APK verifies the activation using the embedded public key. The private licensing key must never be committed to the repository or embedded in an APK.

The purchase screen opens WhatsApp, the phone dialer, or the email application with the role, organization ID, device code, and activation request already included.

## Production packages

Version: `2.7.1-production`

Version code: `217`

Expected signed release APKs:

- Qatra Pro — Administration
- Qatra Pro — Field Reader
- Qatra Pro — Collector
- Qatra Pro — Cashier

The signed release workflow requires the permanent Android release keystore secrets and the approval phrase `READY_FOR_PRODUCTION`. The workflow verifies source checks, regression tests, Android Lint, APK signatures, and SHA-256 checksums before uploading the production artifact.

The production pull request must pass the four-APK CI validation before it is merged into `main`.
